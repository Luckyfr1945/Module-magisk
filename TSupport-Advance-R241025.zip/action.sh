#!/system/bin/sh

# Setting Directory
MODPATH="$(dirname "$(readlink -f "$0")")"

# Core Function

check_internet() {
    # Ping Google DNS server to check for Internet connectivity
    if ! ping -c 1 8.8.8.8 > /dev/null 2>&1; then
        echo -e "\n! Unable to connect to Internet" && sleep 3.5 && exit  # Abort if no Internet connection
    fi
}

cleaner() {

    # Remove the key file if it exists
    [ -f $MODPATH/key ] && rm -rf "$MODPATH/key"
    
    # Remove PIXEL_BETA_HTML file if it exists
    [ -f $DIR/PIXEL_BETA_HTML ] && su -c "rm -rf $MODPATH/BETA"
    
    # Remove PIXEL_GET_HTML file if it exists
    [ -f $DIR/PIXEL_GET_HTML ] && su -c "rm -rf $MODPATH/GET_PIXEL"
    
    # Remove PIXEL_GSI_HTML file if it exists
    [ -f $DIR/PIXEL_GSI_HTML ] && su -c "rm -rf $MODPATH/PIXEL"
    
}

# Mode Function

fingerprint() {
    # Check if the fp.sh file exists and execute it with root privileges
    [ -f $MODPATH/fp.sh ] && sh $MODPATH/fp.sh || echo -e "! Error to get fingerprint"   
}

keybox() {
    # Check if the key.sh file exists and execute it with root privileges
    [ -f $MODPATH/key.sh ] && sh $MODPATH/key.sh || echo -e "! Error to get keybox"
}

shamiko() {
    # Displaying a message regarding TSupport and Shamiko support
    echo "|| TSupport | Shamiko Support ||"
    
    # Define the path to the Shamiko configuration directory
    PATH="/data/adb/shamiko"
    
    [ ! -d /data/adb/modules/zygisk_shamiko ] && rm -rf $PATH
    
    # Check if the whitelist file exists
    if [ -d $PATH ] && [ -f $PATH/whitelist ]; then
        echo "> Shamiko Mode : Whitelist"  # Notify that Shamiko is in the whitelist
        sleep 1.5  # Pause for 1 second
        echo "> Change to Blacklist"  # Notify the user about changing to blacklist
        rm -rf $PATH/whitelist  # Remove the whitelist file
    
    # Check if the blacklist file exists (assuming this was meant)
    elif [ -d $PATH ] && [ ! -f $PATH/whitelist ]; then
        echo "> Shamiko Mode : Blacklist"  # Notify that Shamiko is not whitelisted
        sleep 1.5  # Pause for 1 second
        echo "> Change to Whitelist"  # Notify the user about changing to whitelist
        touch $PATH/whitelist  # Create the whitelist file
    
    # If Shamiko is neither whitelisted nor blacklisted
    else
        echo "! Shamiko not detected"  # Notify that Shamiko is not detected
        sleep 1.3 && exit
    fi
    
    # Sleep for 1 seconds and print result then sleep 1.3 second before exiting the script
    sleep 1 && echo "> Done" && sleep 1.3 && exit
}

key() {
    local option_name=$1
    local option1=$2
    local option2=$3
    local results=$4

    echo -e "\n[ VOL+ ] = [ $option1 ]"
    echo "[ VOL- ] = [ $option2 ]"
    echo "[ Hold Screen ] = [ Shamiko ]"
    echo -e "\nYour selection for $option_name ?"

    local maxtouch=3  # Set the touch
    local touches=0  # Initialize elapsed time

    while true; do
        keys=$(getevent -lqc1)
        
        # Check for timeout
        if [ "$touches" -ge "$maxtouch" ]; then
            echo -e "Set to Shamiko\n"  # Print timeout message
            return 1  # Exit the function with a timeout status
        fi

        if echo "$keys" | grep -q 'KEY_VOLUMEUP.*DOWN'; then
            echo "$option_name set to $option1"
            result=0
            return 0  # Return with success status for option1
        elif echo "$keys" | grep -q 'KEY_VOLUMEDOWN.*DOWN'; then
            echo "$option_name set to $option2"
            result=1
            return 1  # Return with success status for option2
        elif echo "$keys" | grep -q 'KEY_POWER.*DOWN'; then
            echo -e "> Power key detected, set to Shamiko ...\n"
            cleaner
            sleep 1
            break
        fi
        sleep 1
        touches=$((touches + 1))  # Increment the elapsed time
    done
}


# ===========

# Mode Selector
echo -e "\n|| TSupport-Advance Action Mode Selector ||"
key Mode Fingerprint Keybox result

# Runner Script
if [ "$result" -eq 0 ]; then
    check_internet
    fingerprint
    cleaner
    exit
elif [ "$result" -eq 1 ]; then
    check_internet
    keybox
    cleaner
    exit
else
    shamiko
fi
cleaner
exit