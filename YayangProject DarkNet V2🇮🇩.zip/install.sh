##########################################################################################
#
# Magisk Module Installer Script
#
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false

##########################################################################################
# Replace list
##########################################################################################

REPLACE="
"

##########################################################################################
# Function Callbacks
##########################################################################################

print_modname() {
  ui_print " "
  ui_print "╔═══════════════════════════════════════════════╗"
  ui_print "║    🅈 🅐 🅨 🅐 🅝 🅖   🅟 🅡 🅞 🅙 🅔 🅒 🅣        ║"
  ui_print "║           🄳 🄰 🅁 🄺   🄽 🄴 🅃   🅅 ,2.0          ║"
  ui_print "║     𝕌 ℕ 𝕀 𝕍 𝔼 ℝ 𝕊 𝔸 𝕃   𝔸 𝕃 𝕃   𝔻 𝔼 𝕍 𝕀 ℂ 𝔼 𝕊     ║"
  ui_print "╚═══════════════════════════════════════════════╝"
  ui_print " "
  sleep 1

  ui_print "🔧 [ CORE PERFORMANCE ENGINE ]"
  ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  ui_print " 🚀 Ultimate CPU Governor & Frequency Boost"
  ui_print " 🎮 Maximum GPU Rendering & Throttle Disable"
  ui_print " 💾 Extreme Memory Management & Optimization"
  ui_print " 📊 Aggressive I/O Scheduler & MMC Block Tuning"
  ui_print " ❄️  Advanced Thermal Management & Control"
  ui_print " 🌐 Intelligent Network Gaming Optimization"
  ui_print " "

  sleep 1
  ui_print "🖥️ [ DISPLAY & RENDERING SYSTEM ]"
  ui_print " ───────────────────────────────"
  ui_print " 🎯 Surface Flinger Ultra Optimization"
  ui_print " ✨ HWUI & Rendering Engine Max Settings"
  ui_print " 🖼️  Frame Buffer & Texture Optimization"
  ui_print " 🎨 GPU Composition & HW Overlay Control"
  ui_print " 📺 Smooth Video Streaming Enhancement"
  ui_print " 👆 Ultra Smooth Scrolling & Touch Response"
  ui_print " "

  sleep 1
  ui_print "⚡ [ CHIPSET SPECIFIC OPTIMIZATION ]"
  ui_print " ──────────────────────────────────"
  ui_print " 📱 Snapdragon Performance Suite"
  ui_print " 🔷 MediaTek Turbo Enhancement" 
  ui_print " ⭐ Exynos Architecture Tuning"
  ui_print " 🔶 Kirin Processor Optimization"
  ui_print " 🎯 Big Little CPU Architecture Tuning"
  ui_print " ⚡ Adreno GPU Max Performance Tuning"
  ui_print " 🔥 Mali GPU Clock & DVFS Control"
  ui_print " "

  sleep 1
  ui_print "💾 [ MEMORY & STORAGE OPTIMIZATION ]"
  ui_print " ──────────────────────────────────"
  ui_print " 🧠 Memory Controller Optimization"
  ui_print " 💨 ZRAM Compression & Management"
  ui_print " 🚀 FSTRIM & Storage Performance Boost"
  ui_print " 🔄 Background Process Cleaner"
  ui_print " 🎯 Gaming Mode & Profile Activation"
  ui_print " "

  sleep 1
  ui_print "🌐 [ NETWORK & CONNECTIVITY ]"
  ui_print " ───────────────────────────"
  ui_print " 📡 TCP Buffer & Network Latency Reduction"
  ui_print " ⚡ 4G/5G/Wi-Fi Signal Optimization"
  ui_print " 🎮 Gaming Network Protocol Enhancement"
  ui_print " 🔄 DNS Response Acceleration"
  ui_print " "

  sleep 1
  ui_print "⚙️ [ SYSTEM OPTIMIZATION ]"
  ui_print " ────────────────────────"
  ui_print " 🎯 CPU Boost Parameters & Governor Tuning"
  ui_print " ✨ Animation Scale & System Responsiveness"
  ui_print " 🔧 Background Services Optimization"
  ui_print " 🛡️ System Security & SELinux Enhancement"
  ui_print " "

  ui_print "╔═══════════════════════════════════════════════╗"
  ui_print "║           🄸 🄽 🅂 🅃 🄰 🄻 🄻 🄰 🅃 🄸 🄾 🄽           ║"
  ui_print "╚═══════════════════════════════════════════════╝"
  sleep 2
}

on_install() {
  ui_print " "
  ui_print "📦 EXTRACTING MODULE FILES..."
  ui_print "▸ System Optimization Files..."
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  
  ui_print "▸ Performance Scripts..."
  unzip -o "$ZIPFILE" 'script/*' -d $MODPATH >&2 2>/dev/null || true
  
  ui_print "▸ Binary Executables..."
  unzip -o "$ZIPFILE" 'bin/*' -d $MODPATH >&2 2>/dev/null || true
  
  ui_print "✅ ALL FILES EXTRACTED SUCCESSFULLY"
  ui_print " "
}

set_permissions() {
  ui_print "🔐 CONFIGURING PERMISSIONS..."
  
  ui_print "▸ Module Directory Permissions..."
  set_perm_recursive $MODPATH 0 0 0755 0644
  
  ui_print "▸ Script Execution Permissions..."
  [ -d "$MODPATH/script" ] && set_perm_recursive $MODPATH/script 0 0 0755 0755
  [ -f "$MODPATH/script/yayangproject.sh" ] && set_perm $MODPATH/script/yayangproject.sh 0 0 0755
  
  ui_print "▸ Binary File Permissions..."
  [ -d "$MODPATH/bin" ] && set_perm_recursive $MODPATH/bin 0 0 0755 0755
  [ -d "$MODPATH/system/bin" ] && set_perm_recursive $MODPATH/system/bin 0 2000 0755 0755
  
  ui_print "▸ Vendor Configuration Permissions..."
  [ -d "$MODPATH/system/vendor" ] && set_perm_recursive $MODPATH/system/vendor 0 0 0755 0644
  [ -d "$MODPATH/system/vendor/etc" ] && set_perm_recursive $MODPATH/system/vendor/etc 0 0 0755 0644
  
  ui_print "✅ PERMISSIONS CONFIGURED"
  ui_print " "
  
  ui_print "╔═══════════════════════════════════════════════╗"
  ui_print "║         🄸 🄽 🅂 🅃 🄰 🄻 🄻 🄰 🅃 🄸 🄾 🄽   🄲 🄾 🄼 🄿 🄻 🄴 🅃 🄴        ║"
  ui_print "╚═══════════════════════════════════════════════╝"
  ui_print " "
  ui_print "🎉 YAYANG PROJECT DARK NET V2.0 INSTALLED!"
  ui_print " "
  ui_print "📱 Recommended: Reboot device to activate tweaks"
  ui_print "⏰ Allow 2-3 boot cycles for full optimization"
  ui_print " "
  ui_print "🌐 Channel: t.me/yayangshibainuproject"
  ui_print "💬 Discussion: t.me/+0IFlcbM8t3k1MTVl"
  ui_print " "
  ui_print "⭐ Thank you for choosing Yayang Project!"
  ui_print " "
  sleep 1
/system/bin/am start -a android.intent.action.VIEW -d "https://t.me/yayangshibainuproject"
  busybox sleep 1
}