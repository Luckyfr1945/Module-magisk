######
# by Kutu Moba

SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE="
"
unzip -o "$ZIPFILE" 'banner' -d $MODPATH >&2
ui_print
ui_print
ui_print "*******************************"
ui_print "            X-THERMAL          "
ui_print "*******************************"
ui_print "**************************** ***"
ui_print "            Kutu Moba          "
ui_print "*******************************"
ui_print
ui_print
sleep 2
ui_print ""
ui_print ""
ui_print "$(awk '{print}' "$MODPATH/banner")"
ui_print ""
sleep 2
ui_print "▒▒▒▒ 𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼 ▒▒▒▒ "
sleep 2
ui_print "- "
ui_print "   ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "   ▒ "
ui_print "   ▒▒▒▒ CODE NAME        : $(getprop ro.product.board) "
sleep 0.2
ui_print "   ▒▒▒▒ VERSION GL       : $(getprop ro.opengles.version) "
sleep 0.2
ui_print "   ▒▒▒▒ SELINUX          : $(getprop ro.boot.selinux) "
sleep 0.2
ui_print "   ▒▒▒▒ KERNEL           : $(uname -r) "
sleep 0.2
ui_print "   ▒▒▒▒ BUILD DATE       : $(getprop ro.system.build.date) "
slepp 0.2
ui_print "   ▒▒▒▒ ANDROID VERSION  : $(getprop ro.system.build.version.release) "
sleep 0.2
ui_print "   ▒▒▒▒ ROM              : $(getprop ro.build.flavor) "
sleep 0.2
ui_print "   ▒▒▒▒ DESCRIPTION ROM  : $(getprop ro.build.description) "
sleep 0.2
ui_print "   ▒▒▒▒ FINGERPRINT      : $(getprop ro.build.fingerprint) "
sleep 0.2
ui_print "   ▒▒▒▒ SECURITY PATCH   : $(getprop ro.build.version.security_patch) "
ui_print "   ▒ "
ui_print "   ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
ui_print "- "
sleep 0.2
ui_print "▒▒▒▒ START INSTALLATION ▒▒▒▒ "
sleep 2
ui_print " "
ui_print " "
ui_print " "
ui_print "- Extracting module files"
unzip -o "$ZIPFILE" 'common/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
cp -af $TMPDIR/code $MODPATH/code
find /system/vendor/ -name "*thermal*" -type f -print0 | while IFS= read -r -d '' nama; do
   if [[ "$nama" == *.conf ]]; then
     mkdir -p "$MODPATH/$nama"
     rmdir "$MODPATH/$nama"
     touch "$MODPATH/$nama"
   fi
done >/dev/null 2>&1
sleep 1
if [ -f /system/bin/thermald ]; then
    mkdir -p $MODPATH/system/bin/thermald
    rmdir $MODPATH/system/bin/thermald
    touch $MODPATH/system/bin/thermald
fi
if [ -f /system/vendor/bin/mi_thermald ]; then
    mkdir -p $MODPATH/system/vendor/bin/mi_thermald
    rmdir $MODPATH/system/vendor/bin/mi_thermald
    touch $MODPATH/system/vendor/bin/mi_thermald
fi
if [ -f /system/vendor/bin/thermal_factory ]; then
    mkdir -p $MODPATH/system/vendor/bin/thermal_factory
    rmdir $MODPATH/system/vendor/bin/thermal_factory
    touch $MODPATH/system/vendor/bin/thermal_factory
fi
if [ -f /system/vendor/bin/thermal-engine ];then
    mkdir -p $MODPATH/system/vendor/bin/thermal-engine
    rmdir $MODPATH/system/vendor/bin/thermal-engine
    touch $MODPATH/system/vendor/bin/thermal-engine
fi
if [ -f /system/vendor/bin/thermal-engine-v2 ]; then
    mkdir -p $MODPATH/system/vendor/bin/thermal-engine-v2
    rmdir $MODPATH/system/vendor/bin/thermal-engine-v2
    touch $MODPATH/system/vendor/bin/thermal-engine-v2
fi
if [ -f /system/vendor/bin/thermal_core ]; then
    mkdir -p $MODPATH/system/vendor/bin/thermal_core
    rmdir $MODPATH/system/vendor/bin/thermal_core
    touch $MODPATH/system/vendor/bin/thermal_core
fi
if [ -f /system/vendor/bin/thermal_intf ]; then
    mkdir -p $MODPATH/system/vendor/bin/thermal_intf
    rmdir $MODPATH/system/vendor/bin/thermal_intf
    touch $MODPATH/system/vendor/bin/thermal_intf
fi
if [ -f /system/lib64/libthermalservice.so ]; then
    mkdir -p $MODPATH/system/lib64/libthermalservice.so
    rmdir $MODPATH/system/lib64/libthermalservice.so
    touch $MODPATH/system/lib64/libthermalservice.so
fi
if [ -f /system/etc/init/init.thermald.rc ]; then
    mkdir -p $MODPATH/system/etc/init/init.thermald.rc
    rmdir $MODPATH/system/etc/init/init.thermald.rc
    touch $MODPATH/system/etc/init/init.thermald.rc
fi
if [ -f /system/vendor/etc/init/android.hardware.thermal@2.0-service.mtk.rc ]; then
   mkdir -p $MODPATH/system/vendor/etc/init/android.hardware.thermal@2.0-service.mtk.rc
   rmdir $MODPATH/system/vendor/etc/init/android.hardware.thermal@2.0-service.mtk.rc
   touch $MODPATH/system/vendor/etc/init/android.hardware.thermal@2.0-service.mtk.rc
fi
if [ -f /system/vendor/etc/init/init.thermal_core.rc ]; then
    mkdir -p $MODPATH/system/vendor/etc/init/init.thermal_core.rc
    rmdir $MODPATH/system/vendor/etc/init/init.thermal_core.rc
    touch $MODPATH/system/vendor/etc/init/init.thermal_core.rc
fi
sleep 2
set_perm_recursive $MODPATH 0 0 0755 0644

