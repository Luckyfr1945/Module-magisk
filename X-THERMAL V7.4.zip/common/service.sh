MODDIR=${0%/*}

while [[ -z $(resetprop sys.boot_completed) ]]; do sleep 5; done

clear
sleep 2
rm -rf /storage/emulated/0/Android/x_thermal
mkdir -p /storage/emulated/0/Android/x_thermal
for zone in /sys/class/thermal/thermal_zone*/mode; do
  echo disabled > $zone
done
echo 0 > /proc/sys/kernel/sched_boost
echo N > /sys/module/msm_thermal/parameters/enabled
echo 0 > /sys/module/msm_thermal/core_control/enabled
echo 0 > /sys/kernel/msm_thermal/enabled
for queue in /sys/block/sd*/queue; do
  echo "0" > "$queue/iostats"
done
for thermal in $(getprop | grep -E 'thermal.*(running|restarting)' | sed -r 's/\[|\]|running|restarting|://g'); do
   echo "$thermal" >> /storage/emulated/0/Android/x_thermal/term
   sleep 0.1
done
for propertii in $(getprop | awk -F '[][]' '/init\.svc/ && /thermal/ {print $2}' | sed 's/init.svc.//'); do
   echo "$propertii" >> /storage/emulated/0/Android/x_thermal/ter
   sleep 0.1
done
for lg in $(getprop | awk -F '[][]' '/init\.svc/ && /logd/ {print $2}' | sed 's/init.svc.//'); do
   echo "$lg" >> /storage/emulated/0/Android/x_thermal/lg
   sleep 0.1
done
lgg=$(cat /storage/emulated/0/Android/x_thermal/lg)
for lag in $lgg; do
   su -c stop "$lag"
   sleep 0.2
done
baca=$(cat /storage/emulated/0/Android/x_thermal/term)
for i in $baca; do
  setprop "$i" stopped
  sleep 0.2
done
stop thermal_core
stop vendor.thermal-hal-2-0.mtk
bacaa=$(cat /storage/emulated/0/Android/x_thermal/ter)
for ii in $bacaa; do
   su -c stop "$ii"
   sleep 0.2
done
sleep 2
for lawang in $(getprop|grep thermal|cut -f1 -d]|cut -f2 -d[|grep -F init.svc.|sed 's/init.svc.//'); do
  stop $lawang
done
for bro in $(getprop|grep thermal|cut -f1 -d]|cut -f2 -d[|grep -F init.svc.); do
  setprop $bro stopped
done
for brooo in $(getprop|grep thermal|cut -f1 -d]|cut -f2 -d[|grep -F init.svc_); do
  setprop $brooo ""
done
find /sys/devices/virtual/thermal -type f -exec chmod 000 {} +
echo '0' > /sys/class/kgsl/kgsl-3d0/throttling
echo '1' > /sys/class/kgsl/kgsl-3d0/force_clk_on
echo '1' > /sys/class/kgsl/kgsl-3d0/force_bus_on
echo '1' > /sys/class/kgsl/kgsl-3d0/force_rail_on
echo '1' > /sys/class/kgsl/kgsl-3d0/force_no_nap
clear
clear
echo " "
echo " "
echo " "