for i in $(getprop | grep 'ro.*thermal' | cut -d '[' -f2 | cut -d ']' -f1); do
  resetprop -n "$i" 0
done
for a in $(getprop | grep 'ro.*thermal' | awk -F '[][]' '{print $2}'); do
   resetprop -n "$a" 0
done