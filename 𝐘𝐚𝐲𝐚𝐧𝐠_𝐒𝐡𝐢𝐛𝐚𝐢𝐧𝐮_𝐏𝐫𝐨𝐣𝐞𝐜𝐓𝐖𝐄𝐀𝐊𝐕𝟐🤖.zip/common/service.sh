#!/system/bin/sh
# UNIVERSAL PERFORMANCE OPTIMIZATION SCRIPT
# DISCLAIMER: Use this script responsibly. Improper use can lead to overheating, reduced battery life, and potential hardware damage.

MODDIR=${0%/*}

echo "Starting universal performance optimizations..."

# ============================================
# UTILITY FUNCTION
# ============================================
# Fungsi untuk mengatur nilai file jika ada
function set_value() {
    local file=$1
    local value=$2
    if [ -f "$file" ]; then
        echo $value > $file
        echo "Set $file to $value"
    else
        echo "File $file not found! Skipping."
    fi
}

# ============================================
# CPU AND SCHEDULER OPTIMIZATIONS
# ============================================
# Menonaktifkan thermal throttling (PERINGATAN: Risiko overheating!)
set_value /sys/module/msm_thermal/core_control/enabled 0

# Memastikan semua core CPU aktif
for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
    set_value "$cpu/online" 1
done

# Menonaktifkan sleep state untuk semua CPU
for idle in /sys/devices/system/cpu/cpu*/cpuidle/state*/disable; do
    set_value $idle 1
done

# Mengatur governor ke "performance" untuk semua CPU
for governor in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    set_value $governor performance
done

# Mengatur scheduler untuk respons maksimal
set_value /proc/sys/kernel/sched_upmigrate 85
set_value /proc/sys/kernel/sched_downmigrate 65
set_value /proc/sys/kernel/sched_prefer_sync_wakee_to_waker 1
set_value /proc/sys/kernel/sched_autogroup_enabled 1
set_value /proc/sys/kernel/sched_latency_ns 20000000
set_value /proc/sys/kernel/sched_min_granularity_ns 1000000
echo "CPU and scheduler optimizations applied."

# ============================================
# GPU OPTIMIZATIONS
# ============================================
# Mengatur governor GPU ke "performance" (jika didukung)
if [ -d /sys/class/kgsl/kgsl-3d0 ]; then
    set_value /sys/class/kgsl/kgsl-3d0/default_pwrlevel 0
    set_value /sys/class/kgsl/kgsl-3d0/devfreq/governor performance
    set_value /sys/class/kgsl/kgsl-3d0/max_pwrlevel 0
    echo "GPU performance mode enabled."
else
    echo "GPU tuning not supported on this device."
fi

# ============================================
# MEMORY AND SWAP OPTIMIZATIONS
# ============================================
# Mengaktifkan KSM (Kernel Samepage Merging)
set_value /sys/kernel/mm/ksm/run 1
set_value /sys/kernel/mm/ksm/sleep_millisecs 1000

# Menyesuaikan parameter VM untuk respons lebih cepat
set_value /proc/sys/vm/dirty_ratio 10
set_value /proc/sys/vm/dirty_background_ratio 5
set_value /proc/sys/vm/swappiness 10
set_value /proc/sys/vm/vfs_cache_pressure 50
echo "Memory optimizations applied."

# ============================================
# STORAGE OPTIMIZATIONS
# ============================================
# Mengurangi overhead I/O
set_value /proc/sys/fs/file-max 2097152

if [ -d /sys/fs/ext4 ]; then
    for options in /sys/fs/ext4/*/options; do
        if [ -f "$options" ]; then
            echo "noatime,nodiratime" > "$options"
            echo "Optimized storage at $options"
        fi
    done
fi

# ============================================
# DISPLAY AND INPUT OPTIMIZATIONS
# ============================================
# Mengurangi latensi display
set_value /sys/devices/virtual/graphics/fb0/pan_display_wait_sleep 0
set_value /sys/devices/virtual/touchscreen/touch_sensitivity 1
echo "Display and input optimizations applied."

# ============================================
# POWER MANAGEMENT TWEAKS
# ============================================
# Menonaktifkan layanan latar belakang yang tidak perlu
if command -v stop >/dev/null 2>&1; then
    stop vendor.logd
    stop logd
    echo "Disabled unnecessary background logging services."
else
    echo "Command 'stop' not found. Skipping service optimization."
fi

# Mengatur mode pengisian daya untuk performa
if [ -f /sys/class/power_supply/battery/input_current_limit ]; then
    set_value /sys/class/power_supply/battery/input_current_limit 2000000
    echo "Charging current limit increased."
fi

# ============================================
# THERMAL MANAGEMENT TWEAKS
# ============================================
# Mengunci file thermal agar tidak dapat diubah
if [ -d /sys/devices/virtual/thermal ]; then
    find /sys/devices/virtual/thermal -type f -exec chmod 000 {} +
    echo "Thermal control files locked."
fi

# Menonaktifkan layanan thermal menggunakan resetprop (Magisk)
if command -v resetprop >/dev/null 2>&1; then
    for thermal in $(resetprop | awk -F '[][]' '/thermal/ {print $2}'); do
        if [[ $(resetprop "$thermal") == running ]] || [[ $(resetprop "$thermal") == restarting ]]; then
            stop "${thermal/init.svc.}"
            sleep 1
            resetprop -n "$thermal" stopped
            echo "Thermal service $thermal stopped."
        fi
    done
else
    echo "Command 'resetprop' not found. Skipping thermal property modification."
fi

# ============================================
# FINAL MESSAGE
# ============================================
echo "Universal performance optimizations applied successfully!"
echo "Monitor your device for temperature and stability."


sleep 5
su -lp 2000 -c "cmd notification post -S bigtext -t 'YAYANG PROJECT TWEAKV2' tag 'TWEAKV2 ACTIVATED'"