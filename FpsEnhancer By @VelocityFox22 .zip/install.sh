SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE=""

print_modname()
{
MODNAME=$(grep_prop name $TMPDIR/module.prop)
MODVER=$(grep_prop version $TMPDIR/module.prop)
DV=$(grep_prop author $TMPDIR/module.prop)
Device=$(getprop ro.product.device)
Model=$(getprop ro.product.model)
Brand=$(getprop ro.product.brand)
Time=$(date "+%d, %b - %H:%M %Z")

sleep 0.1
echo "-------------------------------------"
echo -e "- Author：\c"
echo "$DV"
sleep 0.1
echo -e "- Module：\c"
echo "$MODNAME"
sleep 0.1
echo -e "- Version：\c"
echo "$MODVER"
sleep 0.1
echo "-------------------------------------"
sleep 0.5
echo "- Brand：$Brand"
sleep 0.1
echo "- Device：$Device"
sleep 0.1
echo "- Model：$Model"
sleep 0.5
echo "-------------------------------------"
}

# Copy/extract your module files into $MODPATH in on_install.
on_install()
{
#Unzip...
    ui_print "- Extracting module files"
    rm -rf /sdcard/Android/FpsEnhancer
    mkdir -p /sdcard/Android/FpsEnhancer
    unzip -j "$ZIPFILE" 'gamelist.txt' -d /sdcard/Android/FpsEnhancer/ > /dev/null
    unzip -o "$ZIPFILE" 'fps' -d "$MODPATH" >&2
chmod +x "$MODPATH"/fps
    unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2

    #Write the FPS value 
refresh_rate=$(dumpsys SurfaceFlinger | grep refresh-rate | cut -f 2 -d : | cut -f 1 -d Hz | awk -F '.00' '{print $1}' | awk -F ' ' '{print $1}')
echo "$refresh_rate" > /sdcard/Android/FpsEnhancer/fps.conf

ui_print " [■□□□□□□□□□] 10% "
sleep 1
  ui_print " [■■□□□□□□□□] 20% "
sleep 0.5
  ui_print " [■■■□□□□□□□] 30% "
sleep 2
  ui_print " [■■■■■□□□□□] 50% "
  ui_print " [■■■■■■□□□□] 60% "
sleep 3
  ui_print " [■■■■■■■□□□] 70% "
sleep 2
  ui_print " [■■■■■■■■□□] 80% "
  ui_print " [■■■■■■■■■□] 90% "
sleep 3
  ui_print " [■■■■■■■■■■] 100% "
sleep 1
echo "- Runing $MODNAME! 🔥"
echo "-------------------------------------"
ui_print "▌Trimming up Partitions... "
fstrim /cache
sleep 0.2
fstrim /data
sleep 0.2
fstrim /product
sleep 0.2
fstrim /system
sleep 0.2
fstrim /vendor
ui_print "▌Waiting.... "
ui_print "▌Ready... "
ui_print "▌Install Successful at $Time !!"
}

set_permissions()
{
    # Here are some examples:
    # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
    # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
    # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
    # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
    set_perm_recursive $MODPATH/system/vendor 0 0 0755 0644 u:object_r:same_process_hal_file:s0
    et_perm_recursive $MODPATH/system/lib* 0 0 0644 u:object_r:system_lib_file:s0
set_perm_recursive $MODPATH  0  0  0755  0644
set_perm_recursive $MODPATH/system/lib 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/lib64 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib/ 0 0 0755 0644 u:object_r:same_process_hal_file:s0
set_perm_recursive $MODPATH/system/vendor/lib64/ 0 0 0755 0644 u:object_r:same_process_hal_file:s0

# add patch permission 32bit
set_perm_recursive $MODPATH/system/vendor/lib/hw/vulkan.adreno.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0

# add patch permission 64bit
set_perm_recursive $MODPATH/system/vendor/lib64/hw/vulkan.adreno.so 0 0 0755 0644 u:object_r:same_process_hal_file:s0

OVERLAY_IMAGE_EXTRA=0
OVERLAY_IMAGE_SHRINK=true
if [ -f "/data/adb/modules/magisk_overlayfs/util_functions.sh" ] && \
    /data/adb/modules/magisk_overlayfs/overlayfs_system --test; then
  . /data/adb/modules/magisk_overlayfs/util_functions.sh
  support_overlayfs
  rm -rf "$MODPATH"/system
fi
}
