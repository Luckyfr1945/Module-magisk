MODDIR=${0%/*}

# Menambahkan skrip ini ke autostart jika belum ada
if [[ ! -f "/data/local/userinit.sh" ]]; then
    echo "#!/system/bin/sh" > /data/local/userinit.sh
    chmod 755 /data/local/userinit.sh
fi

if ! grep -q "$BASEDIR/$(basename "$0")" /data/local/userinit.sh; then
    echo "sh $BASEDIR/$(basename "$0") &" >> /data/local/userinit.sh
fi
