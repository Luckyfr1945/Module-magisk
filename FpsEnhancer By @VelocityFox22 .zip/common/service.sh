#!/system/bin/sh

/data/adb/modules/FpsEnhancer/fps