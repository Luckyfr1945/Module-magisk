SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

REPLACE="
"

print_modname() {
  ui_print " "
  ui_print "******************************************"
  ui_print "   🚀 YAYANGPROJECT THERMAL V5 ULTIMATE   "
  ui_print "******************************************"
  ui_print " "
  ui_print "        🎮 GAMING EDITION V5.0 🎮        "
  ui_print " "
  ui_print "******************************************"
  sleep 1
  ui_print " "
  ui_print "⚡ Codename    : Yayang Project Disable Thermal V5"
  sleep 0.8
  ui_print "🔥 Edition     : ULTIMATE GAMING EDITION"
  sleep 0.8
  ui_print "🤖 Features    : AUTO CHIPSET DETECTION"
  sleep 0.8
  ui_print "📶 Features    : WIFI NO LIMIT OPTIMIZER"
  sleep 0.8
  ui_print "🎯 Features    : MTK + SNAPDRAGON + EXYNOS"
  sleep 0.8
  ui_print "🚀 Features    : MAX PERFORMANCE BOOST"
  sleep 0.8
  ui_print "📱 Tik-Tok     : Yanz.Kitsune"
  sleep 0.6
  ui_print "📷 Instagram   : YayangShibainu"
  sleep 0.6
  ui_print "🏢 Publisher   : Yayang Project"
  sleep 0.6
  ui_print "📲 Channel     : t.me/yayangshibainuproject"
  sleep 1
  
  ui_print " "
  ui_print "******************************************"
  ui_print "           DEVICE INFORMATION"
  ui_print "******************************************"
  sleep 0.8
  ui_print "📅 DATE     : $(date +"%Y-%m-%d %H:%M:%S")"
  sleep 0.6
  ui_print "📱 DEVICE   : $(getprop ro.product.model)"
  sleep 0.6
  ui_print "🤖 Android  : $(getprop ro.build.version.release)"
  sleep 0.6
  ui_print "🏷️️ BRAND    : $(getprop ro.product.brand)"
  sleep 0.6
  ui_print "📋 CODE     : $(getprop ro.product.board)"
  sleep 0.6
  ui_print "⚙️️ MODEL    : $(getprop ro.hardware)"
  sleep 0.6
  ui_print "🔧 KERNEL   : $(uname -r)"
  sleep 0.6
  ui_print "🏗️️ PLATFORM : $(getprop ro.board.platform)"
  sleep 1
  
  ui_print " "
  ui_print "******************************************"
  ui_print "        CHIPSET DETECTION"
  ui_print "******************************************"
  sleep 1
  
  # Run chipset detection during installation
  SOC_VENDOR=$(getprop ro.soc.manufacturer)
  PLATFORM=$(getprop ro.board.platform)
  
  case "$PLATFORM" in
    mt*)
      ui_print "✅ Detected: MEDIATEK (MTK) CHIPSET"
      ui_print "🔧 Loading MTK-specific optimizations..."
      ;;
    msm*|qcom*|sdm*|sm*|sc*|apq*)
      ui_print "✅ Detected: QUALCOMM SNAPDRAGON CHIPSET"
      ui_print "🔧 Loading Snapdragon-specific optimizations..."
      ;;
    exynos*|universal*)
      ui_print "✅ Detected: SAMSUNG EXYNOS CHIPSET"
      ui_print "🔧 Loading Exynos-specific optimizations..."
      ;;
    sp986*|ums*|t310*)
      ui_print "✅ Detected: UNISOC CHIPSET"
      ui_print "🔧 Loading UNISOC-specific optimizations..."
      ;;
    *)
      ui_print "⚠️  Unknown chipset detected"
      ui_print "🔧 Loading universal optimizations..."
      ;;
  esac
  
  sleep 2
  
  ui_print " "
  ui_print "******************************************"
  ui_print "        INSTALLATION IN PROGRESS"
  ui_print "******************************************"
  sleep 1
  
  ui_print " "
  ui_print "🔧 Preparing system for ultimate gaming..."
  sleep 1
  ui_print "🔵 [■□□□□□□□□□] 10%"
  sleep 0.5
  
  ui_print " "
  ui_print "🔥 Installing chipset detector..."
  sleep 1
  ui_print "🔵 [■■□□□□□□□□] 20%"
  sleep 0.5
  
  ui_print " "
  ui_print "📶 Installing WiFi no limit optimizer..."
  sleep 1
  ui_print "🔵 [■■■□□□□□□□] 30%"
  sleep 0.5
  
  ui_print " "
  ui_print "🚀 Installing performance booster..."
  sleep 1
  ui_print "🔵 [■■■■□□□□□□] 40%"
  sleep 0.5
  
  ui_print " "
  ui_print "🎮 Installing gaming optimizations..."
  sleep 1
  ui_print "🔵 [■■■■■□□□□□] 50%"
  sleep 0.5
  
  ui_print " "
  ui_print "🔧 Configuring thermal disable system..."
  sleep 1
  ui_print "🔵 [■■■■■■□□□□] 60%"
  sleep 0.5
  
  ui_print " "
  ui_print "📡 Optimizing network stack..."
  sleep 1
  ui_print "🔵 [■■■■■■■□□□] 70%"
  sleep 0.5
  
  ui_print " "
  ui_print "⚡ Applying extreme gaming patches..."
  sleep 1
  ui_print "🔵 [■■■■■■■■□□] 80%"
  sleep 0.5
  
  ui_print " "
  ui_print "🔒 Setting up stability safeguards..."
  sleep 1
  ui_print "🔵 [■■■■■■■■■□] 90%"
  sleep 0.5
  
  ui_print " "
  ui_print "✅ Finalizing installation..."
  sleep 2
  ui_print "🟢 [■■■■■■■■■■] 100%"
  sleep 1
  
  ui_print " "
  ui_print "******************************************"
  ui_print "      INSTALLATION SUCCESSFUL!"
  ui_print "******************************************"
  ui_print " "
  ui_print "🎉 Yayang Project Disable Thermal V5"
  ui_print "   Ultimate Gaming Edition has been installed!"
  sleep 1
  
  ui_print " "
  ui_print "******************************************"
  ui_print "           FEATURES ACTIVATED"
  ui_print "******************************************"
  ui_print " "
  ui_print "✅ AUTO CHIPSET DETECTION"
  ui_print "✅ COMPLETE THERMAL DISABLE"
  ui_print "✅ WIFI NO LIMIT OPTIMIZER"
  ui_print "✅ MAXIMUM CPU/GPU PERFORMANCE"
  ui_print "✅ GAMING MODE EXTREME"
  ui_print "✅ NETWORK OPTIMIZATION"
  ui_print "✅ STABILITY IMPROVEMENTS"
  ui_print "✅ BUG-FREE OPERATION"
  sleep 1
  
  ui_print " "
  ui_print "******************************************"
  ui_print "           GAMING BENEFITS"
  ui_print "******************************************"
  ui_print " "
  ui_print "🎮 Higher FPS in games"
  ui_print "📶 Faster WiFi speeds"
  ui_print "🔥 No thermal throttling"
  ui_print "⚡ Maximum CPU performance"
  ui_print "🚀 Reduced input lag"
  ui_print "📡 Stable connection"
  ui_print "🔋 Optimized battery usage"
  ui_print "💪 Enhanced stability"
  sleep 1
  
  ui_print " "
  ui_print "******************************************"
  ui_print "           CREDITS & THANKS"
  ui_print "******************************************"
  ui_print " "
  ui_print "🌟 Special thanks to our contributors:"
  ui_print "   👤 @ALL MEMBER YAYANG PROJECT"
  ui_print "   👤 @Allah SWT"
  ui_print " "
  ui_print "🌟 And all Yayang Project supporters!"
  sleep 1
  
  ui_print " "
  ui_print "📲 Join our community for updates:"
  ui_print "   👉 https://t.me/yayangshibainuproject"
  sleep 1
  
  ui_print " "
  ui_print "⚠️  WARNING: ULTIMATE GAMING MODE ACTIVATED"
  ui_print "    All thermal protections disabled!"
  ui_print "    Maximum performance enabled!"
  ui_print "    Use at your own risk!"
  sleep 2
  
  ui_print " "
  ui_print "******************************************"
  ui_print "        PLEASE REBOOT YOUR DEVICE"
  ui_print "******************************************"
  ui_print " "
  ui_print "🔄 Rebooting will apply all changes..."
  ui_print "🎮 Gaming mode will activate on boot!"
  sleep 1
  
  # Open Telegram channel
  /system/bin/am start -a android.intent.action.VIEW -d "https://t.me/yayangshibainuproject" >/dev/null 2>&1
  
  ui_print " "
  ui_print "💎 Thank you for choosing Yayang Project!"
  ui_print " "
  sleep 2
}

on_install() {
  ui_print "- Extracting module files..."
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  
  ui_print "- Installing chipset detector..."
  unzip -o "$ZIPFILE" 'common/chipset_detector.sh' -d $MODPATH >&2
  
  ui_print "- Installing WiFi optimizer..."
  unzip -o "$ZIPFILE" 'common/wifi_optimizer.sh' -d $MODPATH >&2
  
  ui_print "- Setting up permissions..."
  chmod 755 $MODPATH/common/chipset_detector.sh 2>/dev/null
  chmod 755 $MODPATH/common/wifi_optimizer.sh 2>/dev/null
  chmod 755 $MODPATH/common/service.sh 2>/dev/null
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm $MODPATH/common/chipset_detector.sh 0 0 0755 2>/dev/null
  set_perm $MODPATH/common/wifi_optimizer.sh 0 0 0755 2>/dev/null
  set_perm $MODPATH/common/service.sh 0 0 0755 2>/dev/null
}