#!/system/bin/sh
# Uninstall script for Yayang Project Thermal V5
# Clean up all modifications

echo "🧹 Uninstalling Yayang Project Thermal V5..."

# Restore thermal configs
mv /vendor/etc/thermal-engine.conf.bak /vendor/etc/thermal-engine.conf 2>/dev/null
mv /vendor/etc/thermal-engine-*.conf.bak /vendor/etc/thermal-engine-*.conf 2>/dev/null
mv /system/vendor/etc/thermal-engine.conf.bak /system/vendor/etc/thermal-engine.conf 2>/dev/null
mv /vendor/bin/thermal-engine.bak /vendor/bin/thermal-engine 2>/dev/null
mv /system/vendor/bin/thermal-engine.bak /system/vendor/bin/thermal-engine 2>/dev/null

# Restore thermal permissions
chmod 755 /vendor/bin/thermal-engine 2>/dev/null
chmod 755 /system/vendor/bin/thermal-engine 2>/dev/null
chmod 644 /vendor/bin/hw/android.hardware.thermal@*.so 2>/dev/null
chmod 755 /vendor/bin/thermald 2>/dev/null

# Enable thermal zones
echo enabled > /sys/class/thermal/thermal_zone*/mode 2>/dev/null

# Restore Snapdragon thermal
echo Y > /sys/module/msm_thermal/parameters/enabled 2>/dev/null
echo 1 > /sys/module/msm_thermal/core_control/enabled 2>/dev/null
echo 1 > /sys/module/msm_thermal/parameters/enabled 2>/dev/null
echo 1 > /sys/kernel/msm_thermal/enabled 2>/dev/null

# Restore MTK thermal
echo 1 > /proc/mtk_thermal/mtk_thermal_zone/enable 2>/dev/null

# Reset properties
setprop vendor.thermal.disable 0 2>/dev/null
setprop thermal.disable 0 2>/dev/null
setprop persist.thermal.disable 0 2>/dev/null
setprop debug.thermal.disable 0 2>/dev/null

# Clean up temporary files
rm -rf /data/local/tmp/chipset_type.txt 2>/dev/null
rm -rf /data/local/tmp/is_mtk.txt 2>/dev/null
rm -rf /data/local/tmp/is_snapdragon.txt 2>/dev/null
rm -rf /data/local/tmp/is_exynos.txt 2>/dev/null
rm -rf /data/local/tmp/is_unisoc.txt 2>/dev/null

echo "✅ Uninstall complete - System restored to default"