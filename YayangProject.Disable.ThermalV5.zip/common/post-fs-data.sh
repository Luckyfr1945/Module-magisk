#!/system/bin/sh
# Post-fs-data script for Yayang Project Thermal V5
# Early initialization for maximum performance

# Wait for system to be ready
sleep 10

echo "🚀 Yayang Project Thermal V5 - Early Initialization"

# Set basic performance properties
setprop ro.config.nocheckin 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_hwc_vds 1

# Optimize early system settings
echo 0 > /proc/sys/vm/swappiness 2>/dev/null

# Early thermal disable (light version)
echo 0 > /sys/class/thermal/thermal_zone*/mode 2>/dev/null

echo "✅ Early initialization complete"