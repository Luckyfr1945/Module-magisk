#!/system/bin/sh
# ULTIMATE THERMAL KILL SCRIPT V5 - UNIVERSAL GAMING EDITION
# AUTO CHIPSET DETECTION • MTK + SNAPDRAGON • WIFI NO LIMIT • MAX PERFORMANCE

# Import chipset detector
. $MODPATH/common/chipset_detector.sh

sleep 30

echo "=========================================="
echo "🚀 YAYANG PROJECT THERMAL V5 ACTIVATED"
echo "   AUTO CHIPSET DETECTION ENABLED"
echo "   $CHIPSET_TYPE OPTIMIZATIONS LOADED"
echo "=========================================="

# Execute chipset-specific optimizations
echo "🎯 Applying $CHIPSET_TYPE specific optimizations..."

if [ "$IS_MTK" = "true" ]; then
    echo "🔧 Loading MTK Thermal Disable..."
    
    # Disable MTK thermal zones
    echo 0 > /sys/class/thermal/thermal_zone*/mode 2>/dev/null
    echo "disabled" > /sys/class/thermal/thermal_zone*/mode 2>/dev/null
    
    # MTK specific thermal disable
    echo 0 > /sys/devices/virtual/thermal/thermal_message/temp_state 2>/dev/null
    echo 0 > /sys/devices/virtual/thermal/thermal_message/modem_limit 2>/dev/null
    echo 0 > /sys/devices/virtual/thermal/thermal_message/wifi_limit 2>/dev/null
    echo 0 > /sys/devices/virtual/thermal/thermal_message/bat_limit 2>/dev/null
    echo 0 > /sys/devices/virtual/thermal/thermal_message/low_bat_limit 2>/dev/null
    
    # MTK thermal engine disable
    echo 0 > /proc/mtk_thermal/mtk_thermal_zone/enable 2>/dev/null
    echo 0 > /proc/mtk_clkmgr/thermal_enable 2>/dev/null
    echo 0 > /sys/devices/virtual/thermal/thermal_zone0/mode 2>/dev/null
    
    # MTK CPU throttling disable
    echo 0 > /proc/ppm/policy/limited_freq 2>/dev/null
    echo 0 > /proc/ppm/policy/thermal_limit 2>/dev/null
    echo performance > /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor 2>/dev/null
    
    # MTK power management disable
    echo 0 > /proc/mtk_power_governor/enable 2>/dev/null
    echo 0 > /sys/module/mtk_pm/parameters/enable 2>/dev/null
    
    # Stop MTK thermal services
    stop mtk_thermal 2>/dev/null
    stop mtk_thermald 2>/dev/null
    stop mtk_thermal_manager 2>/dev/null
    stop mtk_thermal_hal 2>/dev/null
    stop mtk_thermal_hal_service 2>/dev/null
    stop thermal_manager 2>/dev/null
    stop perfmgr 2>/dev/null
    stop perfserv 2>/dev/null
    stop power_hal 2>/dev/null
    
    # Kill MTK thermal processes
    killall -9 mtk_thermal 2>/dev/null
    killall -9 mtk_thermald 2>/dev/null
    killall -9 mtk_thermal_manager 2>/dev/null
    killall -9 thermal_manager 2>/dev/null
    killall -9 perfmgr 2>/dev/null
    killall -9 perfserv 2>/dev/null
    killall -9 mtk_perf 2>/dev/null
    
    echo "✅ MTK optimizations complete!"
fi

if [ "$IS_SNAPDRAGON" = "true" ]; then
    echo "🔧 Loading Snapdragon Thermal Disable..."
    
    # Disable all thermal zones
    echo 0 > /sys/class/thermal/thermal_zone*/mode 2>/dev/null
    echo "disabled" > /sys/class/thermal/thermal_zone*/mode 2>/dev/null
    
    # Snapdragon specific thermal disable
    echo N > /sys/module/msm_thermal/parameters/enabled 2>/dev/null
    echo 0 > /sys/module/msm_thermal/core_control/enabled 2>/dev/null
    echo 0 > /sys/module/msm_thermal/parameters/enabled 2>/dev/null
    echo 0 > /sys/kernel/msm_thermal/enabled 2>/dev/null
    echo 0 > /sys/module/thermal_core/parameters/enabled 2>/dev/null
    
    # Snapdragon CPU throttling disable
    echo 0 > /proc/sys/kernel/sched_boost 2>/dev/null
    echo performance > /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor 2>/dev/null
    
    # Snapdragon power management disable
    echo 0 > /sys/module/msm_pm/parameters/lpm_levels 2>/dev/null
    echo 0 > /sys/module/msm_pm/parameters/suspend_mode 2>/dev/null
    
    # Stop Snapdragon thermal services
    stop thermal 2>/dev/null
    stop thermald 2>/dev/null
    stop thermal-engine 2>/dev/null
    stop thermal_manager 2>/dev/null
    stop thermal-manager 2>/dev/null
    stop thermal_mnt_hal_service 2>/dev/null
    stop thermal-hal 2>/dev/null
    stop thermalservice 2>/dev/null
    stop thermalloadalgod 2>/dev/null
    stop mi_thermald 2>/dev/null
    stop mi_thermal 2>/dev/null
    stop mi_thermald_remote 2>/dev/null
    stop vendor.thermal-hal-1-0 2>/dev/null
    stop vendor.thermal-hal-2-0 2>/dev/null
    stop vendor.thermal-engine 2>/dev/null
    stop vendor.thermal_manager 2>/dev/null
    stop vendor.thermal-manager 2>/dev/null
    stop vendor.thermal-symlinks 2>/dev/null
    stop vendor.thermal-hal 2>/dev/null
    stop vendor-thermal-1-0 2>/dev/null
    stop vendor-thermal-2-0 2>/dev/null
    stop android.thermal-hal 2>/dev/null
    stop thermal_misc_service 2>/dev/null
    stop thermal_core_service 2>/dev/null
    stop sec-thermal-1-0 2>/dev/null
    stop debug_pid.sec-thermal-1-0 2>/dev/null
    stop thermal_symlinks 2>/dev/null
    stop thermal_hal_service 2>/dev/null
    stop thermal_hal_1_0 2>/dev/null
    stop thermal_hal_2_0 2>/dev/null
    stop qti-thermal 2>/dev/null
    stop qcom-thermal 2>/dev/null
    stop oppo_thermal 2>/dev/null
    stop oneplus_thermal 2>/dev/null
    stop samsung_thermal 2>/dev/null
    stop xiaomi_thermal 2>/dev/null
    stop realme_thermal 2>/dev/null
    stop vivo_thermal 2>/dev/null
    stop honor_thermal 2>/dev/null
    stop huawei_thermal 2>/dev/null
    stop mediatek_thermal 2>/dev/null
    stop mtk-thermal 2>/dev/null
    stop exynos-thermal 2>/dev/null
    
    # Kill Snapdragon thermal processes
    killall -9 thermal-engine 2>/dev/null
    killall -9 thermald 2>/dev/null
    killall -9 mi_thermald 2>/dev/null
    killall -9 thermal_manager 2>/dev/null
    killall -9 thermal-hal 2>/dev/null
    killall -9 android.hardware.thermal@ 2>/dev/null
    killall -9 vendor.thermal 2>/dev/null
    killall -9 qti_thermal 2>/dev/null
    killall -9 qcom_thermal 2>/dev/null
    pkill -f thermal 2>/dev/null
    pkill -f thermald 2>/dev/null
    pkill -f mi_thermald 2>/dev/null
    pkill -f thermal-engine 2>/dev/null
    pkill -f thermal-manager 2>/dev/null
    pkill -f thermal-hal 2>/dev/null
    pkill -f thermalloadalgod 2>/dev/null
    
    echo "✅ Snapdragon optimizations complete!"
fi

if [ "$IS_EXYNOS" = "true" ]; then
    echo "🔧 Loading Exynos Thermal Disable..."
    
    # Exynos specific thermal disable
    echo 0 > /sys/devices/virtual/thermal/thermal_zone*/mode 2>/dev/null
    echo 0 > /sys/module/exynos_thermal/parameters/enabled 2>/dev/null
    
    # Stop Exynos thermal services
    stop sec-thermal-1-0 2>/dev/null
    stop debug_pid.sec-thermal-1-0 2>/dev/null
    stop exynos-thermal 2>/dev/null
    
    # Kill Exynos thermal processes
    killall -9 sec_thermal 2>/dev/null
    killall -9 exynos_thermal 2>/dev/null
    
    echo "✅ Exynos optimizations complete!"
fi

if [ "$IS_UNISOC" = "true" ]; then
    echo "🔧 Loading UNISOC Thermal Disable..."
    
    # UNISOC specific thermal disable
    echo 0 > /sys/devices/virtual/thermal/thermal_zone*/mode 2>/dev/null
    echo 0 > /sys/module/sprd_thermal/parameters/enabled 2>/dev/null
    
    # Stop UNISOC thermal services
    stop sprd-thermal 2>/dev/null
    stop unisoc-thermal 2>/dev/null
    
    # Kill UNISOC thermal processes
    killall -9 sprd_thermal 2>/dev/null
    killall -9 unisoc_thermal 2>/dev/null
    
    echo "✅ UNISOC optimizations complete!"
fi

# Universal thermal disable
echo "🔥 Applying universal thermal disable..."

# Disable I/O stats for performance storage
echo "💾 Optimizing storage performance..."
for queue in /sys/block/*/queue; do
    echo "0" > "$queue/iostats" 2>/dev/null
    echo "deadline" > "$queue/scheduler" 2>/dev/null
done

# Disable specific thermal parameters
echo 0 > /sys/class/thermal/thermal_message/temp_state 2>/dev/null
echo 0 > /sys/class/thermal/thermal_message/modem_limit 2>/dev/null
echo 0 > /sys/class/thermal/thermal_message/wifi_limit 2>/dev/null
echo 0 > /sys/class/thermal/thermal_message/poor_modem_limit 2>/dev/null
echo 0 > /sys/class/thermal/thermal_message/market_download_limit 2>/dev/null
echo 1 > /sys/class/drm/card0-DSI-1/thermal_hbm_disabled 2>/dev/null

sleep 5

# ==============================================
# SETPROP DISABLE - UNIVERSAL
# ==============================================
echo "🔧 Disabling thermal via system properties..."

# Set all thermal service to stopped
setprop init.svc.thermal stopped 2>/dev/null
setprop init.svc.thermald stopped 2>/dev/null
setprop init.svc.thermal-engine stopped 2>/dev/null
setprop init.svc.thermal_manager stopped 2>/dev/null
setprop init.svc.thermal-manager stopped 2>/dev/null
setprop init.svc.thermal_mnt_hal_service stopped 2>/dev/null
setprop init.svc.thermal-hal stopped 2>/dev/null
setprop init.svc.thermalservice stopped 2>/dev/null
setprop init.svc.thermalloadalgod stopped 2>/dev/null
setprop init.svc.mi_thermald stopped 2>/dev/null
setprop init.svc.mi-thermald stopped 2>/dev/null
setprop init.svc.vendor.thermal-symlinks stopped 2>/dev/null
setprop init.svc.vendor.thermal-engine stopped 2>/dev/null
setprop init.svc.vendor.thermal_manager stopped 2>/dev/null
setprop init.svc.vendor.thermal-manager stopped 2>/dev/null
setprop init.svc.vendor.thermal-hal stopped 2>/dev/null
setprop init.svc.vendor.thermal-hal-1-0 stopped 2>/dev/null
setprop init.svc.vendor.thermal-hal-2-0 stopped 2>/dev/null
setprop init.svc.vendor-thermal-1-0 stopped 2>/dev/null
setprop init.svc.vendor-thermal-2-0 stopped 2>/dev/null
setprop init.svc.android.thermal-hal stopped 2>/dev/null
setprop init.svc.sec-thermal-1-0 stopped 2>/dev/null
setprop init.svc.debug_pid.sec-thermal-1-0 stopped 2>/dev/null

# Disable thermal hal
setprop vendor.thermal.disable 1 2>/dev/null
setprop thermal.disable 1 2>/dev/null
setprop persist.thermal.disable 1 2>/dev/null
setprop debug.thermal.disable 1 2>/dev/null
setprop vendor.debug.thermal.disable 1 2>/dev/null

sleep 2

# ==============================================
# DISABLE THERMAL CONFIGS - UNIVERSAL
# ==============================================
echo "🔧 Disabling thermal configuration files..."

# Rename thermal config files
mv /vendor/etc/thermal-engine.conf /vendor/etc/thermal-engine.conf.bak 2>/dev/null
mv /vendor/etc/thermal-engine-*.conf /vendor/etc/thermal-engine-*.conf.bak 2>/dev/null
mv /system/vendor/etc/thermal-engine.conf /system/vendor/etc/thermal-engine.conf.bak 2>/dev/null
mv /vendor/bin/thermal-engine /vendor/bin/thermal-engine.bak 2>/dev/null
mv /system/vendor/bin/thermal-engine /system/vendor/bin/thermal-engine.bak 2>/dev/null

# Remove thermal execute permissions
chmod 000 /vendor/bin/thermal-engine 2>/dev/null
chmod 000 /system/vendor/bin/thermal-engine 2>/dev/null
chmod 000 /vendor/bin/hw/android.hardware.thermal@*.so 2>/dev/null
chmod 000 /vendor/bin/thermald 2>/dev/null

sleep 2

# ==============================================
# WIFI OPTIMIZER ACTIVATION
# ==============================================
echo "📶 Activating WiFi No Limit Optimizer..."
. $MODPATH/common/wifi_optimizer.sh

sleep 3

# ==============================================
# GAMING PERFORMANCE BOOST
# ==============================================
echo "🎮 Activating Gaming Performance Boost..."

# Set maximum CPU frequency for all cores
for cpu in /sys/devices/system/cpu/cpu*; do
    if [ -d "$cpu/cpufreq" ]; then
        echo "performance" > "$cpu/cpufreq/scaling_governor" 2>/dev/null
        echo 0 > "$cpu/cpufreq/scaling_min_freq" 2>/dev/null
        cat "$cpu/cpufreq/scaling_max_freq" > "$cpu/cpufreq/scaling_min_freq" 2>/dev/null
    fi
done

# Disable CPU hotplugging
echo 1 > /sys/devices/virtual/cpuhotplug/force_online 2>/dev/null
for cpu in /sys/devices/system/cpu/cpu*/online; do
    echo 1 > "$cpu" 2>/dev/null
done

# Set memory governor to performance
echo performance > /sys/devices/virtual/memory/mi_ion/total_heap_kb 2>/dev/null
echo 0 > /proc/sys/vm/swappiness 2>/dev/null
echo 1 > /proc/sys/vm/drop_caches 2>/dev/null

# Disable all CPU idle states
echo 0 > /sys/devices/system/cpu/cpu*/cpuidle/state*/disable 2>/dev/null

# Set maximum GPU frequency
for gpu in /sys/class/kgsl/kgsl-3d0/devfreq/gpu*; do
    echo performance > "$gpu/governor" 2>/dev/null
    echo 0 > "$gpu/min_freq" 2>/dev/null
    cat "$gpu/max_freq" > "$gpu/min_freq" 2>/dev/null
done 2>/dev/null

# Gaming mode properties
setprop ro.config.nocheckin 1 2>/dev/null
setprop debug.sf.disable_backpressure 1 2>/dev/null
setprop debug.sf.enable_hwc_vds 1 2>/dev/null
setprop ro.surface_flinger.max_frame_buffer_acquired_buffers 3 2>/dev/null

sleep 2

# ==============================================
# FINAL CLEANUP
# ==============================================
echo "🧹 Final cleanup and optimization..."

# Disable all thermal policy
echo 0 > /sys/class/thermal/thermal_message/* 2>/dev/null

# Force stop any remaining thermal services
am force-stop com.android.thermal 2>/dev/null
am force-stop com.miui.thermal 2>/dev/null

# Clear thermal cache
rm -rf /data/system/thermal/* 2>/dev/null
rm -rf /data/vendor/thermal/* 2>/dev/null
rm -rf /cache/thermal/* 2>/dev/null

# Optimize system for gaming
echo 1 > /proc/sys/vm/dirty_ratio 2>/dev/null
echo 10 > /proc/sys/vm/dirty_background_ratio 2>/dev/null
echo 1000000 > /proc/sys/net/core/rmem_default 2>/dev/null
echo 1000000 > /proc/sys/net/core/wmem_default 2>/dev/null

echo "=========================================="
echo "🚀 YAYANG PROJECT THERMAL V5 COMPLETE!"
echo "   CHIPSET: $CHIPSET_TYPE"
echo "   MODE: ULTIMATE GAMING"
echo "   WIFI: NO LIMIT ACTIVATED"
echo "   PERFORMANCE: MAXIMUM"
echo "   THERMAL: COMPLETELY DISABLED"
echo "   STABILITY: OPTIMIZED"
echo "=========================================="
echo "🎮 GAMING MODE EXTREME ACTIVATED!"
echo "📶 WiFi PERFORMANCE: UNLIMITED!"
echo "🔥 THERMAL THROTTLING: REMOVED!"
echo "⚡ CPU/GPU: MAXIMUM PERFORMANCE!"
echo "=========================================="

# Keep script running to prevent respawn
while true; do
    # Monitor and kill any respawned thermal processes
    pkill -f thermal 2>/dev/null
    pkill -f thermald 2>/dev/null
    
    # Maintain gaming performance
    for cpu in /sys/devices/system/cpu/cpu*; do
        if [ -d "$cpu/cpufreq" ]; then
            echo "performance" > "$cpu/cpufreq/scaling_governor" 2>/dev/null
        fi
    done 2>/dev/null
    
    # Maintain WiFi optimization
    iwconfig wlan0 power off 2>/dev/null
    
    sleep 10
done