#!/system/bin/sh
# WIFI NO LIMIT OPTIMIZER FOR GAMING
# Maximize WiFi performance for gaming and streaming

echo "📶 Activating WiFi No Limit Optimizer..."

# Disable WiFi power saving
echo "⚡ Disabling WiFi power saving..."
settings put global wifi_wakeup_available 0 2>/dev/null
settings put global wifi_wakeup_enabled 0 2>/dev/null
settings put global wifi_scan_always_enabled 1 2>/dev/null
settings put global wifi_networks_available_notification_on 0 2>/dev/null

# Optimize WiFi scanning
echo "🔍 Optimizing WiFi scanning..."
settings put global wifi_scan_interval_p2p 15 2>/dev/null
settings put global wifi_scan_interval 15 2>/dev/null
settings put global wifi_framework_scan_interval_ms 15000 2>/dev/null

# Disable WiFi throttling
echo "🚀 Disabling WiFi throttling..."
settings put global cellular_on 0 2>/dev/null
settings put global airplane_mode_on 0 2>/dev/null

# Optimize WiFi antenna configuration
echo "📡 Optimizing WiFi antenna..."
iwconfig wlan0 power off 2>/dev/null
iwpriv wlan0 set PowerSave=0 2>/dev/null
iwpriv wlan0 set PowerSaveMode=0 2>/dev/null
iwpriv wlan0 set BcnInterval=100 2>/dev/null

# Set WiFi regulatory domain to maximum power
echo "🌍 Setting maximum WiFi power..."
iw reg set US 2>/dev/null
iw reg set BO 2>/dev/null

# Disable WiFi coexistence
echo "📶 Disabling WiFi coexistence limits..."
echo 0 > /sys/module/ath10k_core/parameters/ath10k_core_ct_packet_log_enable 2>/dev/null
echo 0 > /sys/module/ath10k_core/parameters/enable_btcoex 2>/dev/null

# Optimize TCP/IP stack for gaming
echo "🌐 Optimizing TCP/IP stack..."
echo 1 > /proc/sys/net/ipv4/tcp_low_latency 2>/dev/null
echo 0 > /proc/sys/net/ipv4/tcp_timestamps 2>/dev/null
echo 0 > /proc/sys/net/ipv4/tcp_sack 2>/dev/null
echo 2 > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null

# Increase network buffers
echo "📊 Increasing network buffers..."
echo 16777216 > /proc/sys/net/core/rmem_max 2>/dev/null
echo 16777216 > /proc/sys/net/core/wmem_max 2>/dev/null
echo 4096 65536 16777216 > /proc/sys/net/ipv4/tcp_rmem 2>/dev/null
echo 4096 65536 16777216 > /proc/sys/net/ipv4/tcp_wmem 2>/dev/null

# Disable network stats collection
echo "📈 Disabling network stats collection..."
settings put global net_stats_enabled 0 2>/dev/null
settings put global net_stats_sample_enabled 0 2>/dev/null

# Optimize DNS for gaming
echo "🌍 Optimizing DNS settings..."
setprop net.dns1 8.8.8.8 2>/dev/null
setprop net.dns2 1.1.1.1 2>/dev/null
setprop net.dns3 9.9.9.9 2>/dev/null

# Gaming mode optimizations
echo "🎮 Activating gaming mode network optimizations..."
settings put global game_doa_mode 1 2>/dev/null
settings put global game_doa_enabled 1 2>/dev/null
settings put global game_mode_enabled 1 2>/dev/null

# Disable background network usage
echo "🔒 Disabling background network usage..."
settings put global restrict_background_data 0 2>/dev/null
settings put global data_saver_mode 0 2>/dev/null

# Optimize network scheduler
echo "⚙️ Optimizing network scheduler..."
echo cfq > /sys/block/*/queue/scheduler 2>/dev/null
echo 0 > /sys/block/*/queue/iosched/fifo_batch 2>/dev/null
echo 1 > /sys/block/*/queue/iosched/quantum 2>/dev/null

# Enable maximum WiFi TX power
echo "📡 Setting maximum WiFi TX power..."
echo 30 > /sys/module/ath10k_core/parameters/ath10k_max_txpower 2>/dev/null
echo 30 > /sys/module/brcmfmac/parameters/rxchain 2>/dev/null
echo 30 > /sys/module/brcmfmac/parameters/txchain 2>/dev/null

# Disable WiFi roaming
echo "📍 Disabling aggressive WiFi roaming..."
settings put global wifi_assistant_ssid_blacklist "" 2>/dev/null
settings put global wifi_open_network_notif_allowed 0 2>/dev/null

# Optimize packet coalescing
echo "📦 Optimizing packet coalescing..."
echo 0 > /sys/module/ath10k_core/parameters/enable_thermal_mitigation 2>/dev/null
echo 0 > /sys/module/ath10k_core/parameters/enable_tx_power_control 2>/dev/null

# Gaming specific WiFi optimizations
echo "🎯 Applying gaming-specific WiFi optimizations..."
# Keep WiFi awake during gaming
echo "online" > /sys/power/wake_lock 2>/dev/null
echo "wifi" > /sys/power/wake_lock 2>/dev/null

# Optimize for low latency gaming
echo 0 > /proc/sys/net/ipv4/tcp_no_metrics_save 2>/dev/null
echo 0 > /proc/sys/net/ipv4/tcp_tw_reuse 2>/dev/null
echo 1000000 > /proc/sys/net/ipv4/tcp_max_orphans 2>/dev/null

echo "✅ WiFi No Limit Optimizer Applied!"
echo "🚀 Maximum WiFi performance activated for gaming!"
echo "📶 All WiFi limits and throttling removed!"

return 0