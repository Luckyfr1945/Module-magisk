#!/system/bin/sh
# UNIVERSAL CHIPSET DETECTOR - MTK vs SNAPDRAGON
# Enhanced detection for maximum compatibility

CHIPSET_TYPE="unknown"
IS_MTK="false"
IS_SNAPDRAGON="false"
IS_EXYNOS="false"
IS_UNISOC="false"

echo "🔍 Starting Universal Chipset Detection..."

# Method 1: Check SoC vendor
SOC_VENDOR=$(getprop ro.soc.manufacturer)
if [ "$SOC_VENDOR" = "MediaTek" ] || [ "$SOC_VENDOR" = "MTK" ]; then
    CHIPSET_TYPE="MTK"
    IS_MTK="true"
    echo "✅ Detected: MediaTek SoC"
fi

if [ "$SOC_VENDOR" = "Qualcomm" ] || [ "$SOC_VENDOR" = "QTI" ]; then
    CHIPSET_TYPE="Snapdragon"
    IS_SNAPDRAGON="true"
    echo "✅ Detected: Qualcomm Snapdragon SoC"
fi

if [ "$SOC_VENDOR" = "Samsung" ]; then
    CHIPSET_TYPE="Exynos"
    IS_EXYNOS="true"
    echo "✅ Detected: Samsung Exynos SoC"
fi

if [ "$SOC_VENDOR" = "UNISOC" ]; then
    CHIPSET_TYPE="UNISOC"
    IS_UNISOC="true"
    echo "✅ Detected: UNISOC SoC"
fi

# Method 2: Check platform property
if [ "$CHIPSET_TYPE" = "unknown" ]; then
    PLATFORM=$(getprop ro.board.platform)
    case "$PLATFORM" in
        mt*)
            CHIPSET_TYPE="MTK"
            IS_MTK="true"
            echo "✅ Detected: MediaTek (mt*)"
            ;;
        msm*|qcom*|sdm*|sm*|sc*|apq*)
            CHIPSET_TYPE="Snapdragon"
            IS_SNAPDRAGON="true"
            echo "✅ Detected: Qualcomm Snapdragon"
            ;;
        exynos*|universal*)
            CHIPSET_TYPE="Exynos"
            IS_EXYNOS="true"
            echo "✅ Detected: Samsung Exynos"
            ;;
        sp986*|ums*|ums*|ums*)
            CHIPSET_TYPE="UNISOC"
            IS_UNISOC="true"
            echo "✅ Detected: UNISOC"
            ;;
    esac
fi

# Method 3: Check CPU architecture
if [ "$CHIPSET_TYPE" = "unknown" ]; then
    CPU_HARDWARE=$(getprop ro.hardware)
    case "$CPU_HARDWARE" in
        mt*)
            CHIPSET_TYPE="MTK"
            IS_MTK="true"
            echo "✅ Detected: MediaTek (hardware)"
            ;;
        msm*|qcom*)
            CHIPSET_TYPE="Snapdragon"
            IS_SNAPDRAGON="true"
            echo "✅ Detected: Qualcomm Snapdragon (hardware)"
            ;;
        exynos*)
            CHIPSET_TYPE="Exynos"
            IS_EXYNOS="true"
            echo "✅ Detected: Samsung Exynos (hardware)"
            ;;
    esac
fi

# Method 4: Check kernel info
if [ "$CHIPSET_TYPE" = "unknown" ]; then
    KERNEL_INFO=$(cat /proc/cpuinfo | grep -i "Hardware\|Processor" | head -1)
    case "$KERNEL_INFO" in
        *MTK*|*MediaTek*|*mt*)
            CHIPSET_TYPE="MTK"
            IS_MTK="true"
            echo "✅ Detected: MediaTek (kernel)"
            ;;
        *Qualcomm*|*MSM*|*SDM*|*SM*|*SC*|*APQ*)
            CHIPSET_TYPE="Snapdragon"
            IS_SNAPDRAGON="true"
            echo "✅ Detected: Qualcomm Snapdragon (kernel)"
            ;;
        *Exynos*|*Universal*)
            CHIPSET_TYPE="Exynos"
            IS_EXYNOS="true"
            echo "✅ Detected: Samsung Exynos (kernel)"
            ;;
    esac
fi

# Method 5: Check build properties
if [ "$CHIPSET_TYPE" = "unknown" ]; then
    BUILD_PRODUCT=$(getprop ro.build.product)
    case "$BUILD_PRODUCT" in
        mt*|MT*)
            CHIPSET_TYPE="MTK"
            IS_MTK="true"
            echo "✅ Detected: MediaTek (build)"
            ;;
        msm*|qcom*|sdm*|sm*)
            CHIPSET_TYPE="Snapdragon"
            IS_SNAPDRAGON="true"
            echo "✅ Detected: Qualcomm Snapdragon (build)"
            ;;
        exynos*)
            CHIPSET_TYPE="Exynos"
            IS_EXYNOS="true"
            echo "✅ Detected: Samsung Exynos (build)"
            ;;
    esac
fi

# Fallback detection
if [ "$CHIPSET_TYPE" = "unknown" ]; then
    # Check for MTK-specific files
    if [ -f "/proc/mtk_lte/online_mode" ] || [ -d "/proc/mtk" ] || [ -f "/system/lib/libmtk_drv.so" ]; then
        CHIPSET_TYPE="MTK"
        IS_MTK="true"
        echo "✅ Detected: MediaTek (file system)"
    fi
fi

if [ "$CHIPSET_TYPE" = "unknown" ]; then
    # Check for Qualcomm-specific files
    if [ -d "/sys/kernel/msm_thermal" ] || [ -f "/sys/module/msm_thermal" ] || [ -f "/system/lib/libril-qc-qmi-1.so" ]; then
        CHIPSET_TYPE="Snapdragon"
        IS_SNAPDRAGON="true"
        echo "✅ Detected: Qualcomm Snapdragon (file system)"
    fi
fi

# Final fallback - assume Snapdragon if still unknown (most common)
if [ "$CHIPSET_TYPE" = "unknown" ]; then
    CHIPSET_TYPE="Snapdragon"
    IS_SNAPDRAGON="true"
    echo "⚠️ Unknown chipset, defaulting to Snapdragon"
fi

# Export variables for use by other scripts
export CHIPSET_TYPE
export IS_MTK
export IS_SNAPDRAGON
export IS_EXYNOS
export IS_UNISOC

echo "🎯 Final Detection Result: $CHIPSET_TYPE"
echo "📱 Device Info: $(getprop ro.product.model)"
echo "🏢 Brand: $(getprop ro.product.brand)"
echo "📋 Platform: $(getprop ro.board.platform)"
echo "🔧 Hardware: $(getprop ro.hardware)"

# Save detection result to file for reference
echo "$CHIPSET_TYPE" > /data/local/tmp/chipset_type.txt
echo "$IS_MTK" > /data/local/tmp/is_mtk.txt
echo "$IS_SNAPDRAGON" > /data/local/tmp/is_snapdragon.txt
echo "$IS_EXYNOS" > /data/local/tmp/is_exynos.txt
echo "$IS_UNISOC" > /data/local/tmp/is_unisoc.txt

return 0