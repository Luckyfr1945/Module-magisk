#!/system/bin/sh

# Sony Xperia Audio Engine - service.sh by YayangProject

# === APPLY AUDIO ENGINE PROPS ===
resetprop -n persist.sony.xperia.audio.enhancer enabled
resetprop -n persist.sony.effect.custom.preset ClearAudio+
resetprop -n persist.sony.effect.preset Studio
resetprop -n persist.sony.clearbass.supported true
resetprop -n persist.sony.dseehx.enabled true
resetprop -n persist.sony.dseehx.auto true
resetprop -n persist.sony.sforce.enabled true
resetprop -n persist.sony.sforce.preset wide
resetprop -n persist.sony.xloud.enabled true
resetprop -n persist.sony.noisereduction.enabled true
resetprop -n persist.sony.sound_effects true
resetprop -n ro.sony.sound.effect enabled

# === AUDIO HIGH-RES & BT ===
resetprop -n persist.audio.hires.enabled true
resetprop -n persist.audio.hires.bt.enabled true
resetprop -n persist.audio.support.24bit true
resetprop -n persist.audio.support.192khz true
resetprop -n ro.audio.usb.pro.audio true
resetprop -n persist.vendor.bt.a2dp.hwa.ldac.quality_index 1004
resetprop -n persist.vendor.bt.a2dp.hwa.enabled true
resetprop -n persist.vendor.bt.a2dp.hwa.supported true
resetprop -n persist.bt.max.a2dp.bitdepth 32
resetprop -n persist.bt.max.a2dp.samplerate 192000

# === GAIN PATCHING ===
for path in \
  /sys/kernel/sound_control/speaker_gain \
  /sys/kernel/sound_control/headphone_gain \
  /sys/class/misc/snd_soc_card/speaker_gain \
  /sys/class/misc/snd_soc_card/headphone_gain \
  /sys/devices/platform/soc/soc:sound/speaker_gain \
  /sys/devices/platform/soc/soc:sound/headphone_gain
do
  [ -e "$path" ] && echo 3 > "$path"
done

# === ALSA HI-RES PATCH (If available) ===
echo 24 > /proc/asound/card0/pcm0p/sub0/sample_bits 2>/dev/null
echo 96000 > /proc/asound/card0/pcm0p/sub0/hw_params 2>/dev/null

# === AUDIO FOLDER PERMISSIONS FIX ===
chmod -R 0771 /vendor/etc/audio 2>/dev/null
chmod 0644 /vendor/etc/audio/*.xml 2>/dev/null

# === CUSTOM MIXER_PATHS (If exists) ===
if [ -f /data/sony_audio/mixer_paths.xml ]; then
  cp -f /data/sony_audio/mixer_paths.xml /vendor/etc/mixer_paths.xml
  chmod 0644 /vendor/etc/mixer_paths.xml
fi

# === OPTIONAL: APPLY PERMISSIVE MODE (if needed) ===
if getenforce | grep -qi Enforcing; then
  setenforce 0
fi

# === OPTIONAL: PATCH AUDIO LIBS PERMISSIONS ===
chmod 0755 /vendor/lib*/soundfx/* 2>/dev/null

# === FORCE STOP MEDIA AND RESET ===
killall audioserver 2>/dev/null
killall mediaserver 2>/dev/null
sleep 1
am startservice --user 0 -n com.android.musicfx/.ControlPanelService 2>/dev/null

# === LOG SUCCESS ===
log -p i -t sony_audio "[YayangProject] Sony Xperia Audio Engine applied successfully"