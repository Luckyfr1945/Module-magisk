# Set permissions


ui_print " Preparing Settings..."
sleep 5
# Set permissions
ui_print " ⚙️ Settings permissions"
sleep 0.5
ui_print " Apply Tweaks & Settings: ✅"
ui_print " "
ui_print " Preparing Settings..."
ui_print " ⚙️ Setting permissions"

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/vendor 0 0 0755 0755

nohup am start -a android.intent.action.VIEW -d https://t.me/mtkvestg99 >/dev/null 2>&1 &
