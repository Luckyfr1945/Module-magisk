allow system_server system_file file write

# context
create { system_lib_file vendor_file vendor_configs_file }
allow { system_file system_lib_file vendor_file vendor_configs_file } labeledfs filesystem associate
allow init { system_file system_lib_file vendor_file vendor_configs_file } { dir file } relabelfrom


#This module supports all devices and is equipped with universal army support 
#Please do not modify or combine this module with other modules because it can result in stopping at the initial boot logo, support for ZnySu and Magisk as well as Su and Kitsune kernels,
#use wisely, at your own risk, best regards, copyright @ZnySu
