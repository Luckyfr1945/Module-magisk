if
elif [[ "$mode" = "performance" ]]; then 
echo 105 > "/storage/emulated/0/Android/ZnySu_Official/target_temp"
elif [[ "$mode" = "fast" ]]; then 
echo 85 > "/storage/emulated/0/Android/ZnySu_Official/target_temp"
fi