#!/sbin/sh
# Don't modify anything after this By Official ZnySu
# All modules are official ZnySu Official copyright, copy paste or changing copyright is prohibited 
# no theft is an act that fools the public, please use the module on the ZnySu channel, not on other channels 
# ZnySu's official module 
# Set what you want to display when installing your module

AUTOMOUNT=false 
PROPFILE=true
LATESTARTSERVICE=true

mkdir -p $NVBASE/modules_update/$MODID/system/
mkdir -p $NVBASE/modules_update/$MODID/system/vendor/
cp /vendor/build.prop $NVBASE/modules_update/$MODID/system/vendor/

sleep 1
sed -i "/offset/d" $NVBASE/modules_update/$MODID/system/vendor/build.prop

sleep 0.2
echo "debug.sf.use_phase_offsets_as_durations=1" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
echo "debug.sf.late.app.duration=16600000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2

sleep 0.2
echo "debug.sf.late.sf.duration=10500000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.frame_rate_multiple_threshold=120" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.earlyGl.sf.duration=16600000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.earlyGl.app.duration=16600000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.hwc_hotplug_error_via_neg_vsync=1" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
sleep 0.2
echo "debug.sf.hwc_hdcp_via_neg_vsync=1" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop

rm /system/framework/vr.jar
print_modname
vendorprop_systemlib64
rm -rf $TMPDIR
ui_print "█████████████████████████████████████████████████"
ui_print ""
ui_print "
⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬜⬛⬛⬜⬜🟥🟥⬜⬜⬛⬛⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛🟥🟥⬜🟥⬜⬜🟥⬜🟥🟥⬛⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬛⬛🟥🟥🟥⬜🟥🟥🟥🟥⬜🟥🟥🟥⬛⬜⬜⬜⬜
⬜⬛⬛⬜⬛⬜⬜⬛🟥🟥⬛⬛⬛⬛⬛⬛🟥🟥🟥⬛⬜⬜⬜⬜
⬛⬜⬜⬛⬛⬜⬜⬛⬛⬛🟥🟥🟥🟥🟥🟥⬛⬛🟥🟥⬛⬜⬜⬜
⬛⬜⬜⬜⬛⬜⬜⬛🟥🟥⬛⬛⬛⬛⬛⬛🟥🟥⬛🟥⬛⬜⬜⬜
⬜⬛⬜⬜⬛⬛⬛⬛⬛⬛⬜⬜🏻🏻⬜⬜⬛⬛🟫⬛⬛⬜⬜⬜
⬛⬜⬜⬜⬛⬜⬜⬜⬛⬜⬜⬛🏻🏻⬛⬜⬜🏻🟫🏻🏻⬛⬜⬜
⬛⬜⬜⬜⬛⬜⬜⬜⬛⬜⬜⬛🏻🏻⬛⬜⬜🏻⬛🏻🏻⬛⬜⬜
⬛⬜⬜⬜🟦⬛⬛⬜⬛🏻🏻🏻🏻🏻🏻🏻🏻🏻🏻⬛🏻⬛⬜⬜
⬜⬛⬛🟦🟦🟦🟦⬛🏻🏻⬛🏻🏻🏻🏻⬛🏻🏻🏻⬛🏻⬛⬜⬜
⬜⬜⬜⬛⬛⬛⬛🟥⬛⬛⬛⬛🏻🏻⬛⬛⬛⬛🏻⬛⬛⬜⬜⬜
⬜⬜⬜⬜⬛🟥🟥🟥⬛⬛⬛⬛⬛⬛⬛⬛⬛🏻⬛⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬛🟥🟥🟥🟥⬛🏻⬛⬛⬛⬛🏻🏻⬛⬛⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬛🟥🟥🟥⬛⬛🏻🏻🏻🏻⬛⬛🟥🟥⬛⬛⬜⬜⬜
⬜⬜⬜⬜⬜⬛🟥🟥🟥🟦🟦⬛⬛⬛⬛🟥🟦⬛🟥🟥🟥⬛⬜⬜
⬜⬜⬜⬜⬜⬜⬛🟥🟦🟦🟦🟦🟥🟥🟥🟥🟦⬛🟥🟥🟥🟥⬛⬜
⬜⬜⬜⬜⬜⬜⬜⬛🟦🟦🟨🟨🟦🟥🟥🟦🟨🟨⬛🟥🟥🟥⬛⬜
⬜⬜⬜⬜⬜⬜⬜⬛🟦🟦🟨🟨🟦🟦🟦🟦🟨🟨⬛🟥🟥🟥⬛⬜
⬜⬜⬜⬜⬜⬜⬜⬛🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦⬛🟥🟥⬛⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦⬛⬛⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬛🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦⬛⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬛🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦⬛⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬛🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦⬛⬜⬜⬜
⬜⬜⬜⬜⬜⬛🟦🟦🟦🟦🟦⬛⬛⬛⬛🟦🟦🟦🟦🟦⬛⬜⬜⬜
⬜⬜⬜⬛⬛⬛🟦🟦🟦🟦⬛⬛⬛⬛⬛⬛🟦🟦🟦🟦⬛⬛⬛⬜
⬜⬜⬛⬛🏻🏻🟫🟫🟧🟧🟫⬛⬜⬜⬛🟫🟧🟧🟫🟫🏻🏻⬛⬛
⬜⬜⬜⬛🟧🟧🟧🟧🟧🟧🟧⬛⬜⬜⬛🟧🟧🟧🟧🟧🟧🟧⬛⬜
⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬛⬜⬜"
ui_print ""
ui_print "█▓▒▒░░░🆅🆂░░░▒▒▓█"
ui_print "
⬜⬜⬜⬜⬜⬜⬜⬛⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬜⬜⬜⬜⬜⬜⬜⬜⬜⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬜⬛⬛⬛⬜⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛🏻🏻🏻🏻🏻⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛🏻🏻⬛🏻🏻⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬜⬜⬛⬛🏻🏻🏻🏻🏻⬛⬛⬜⬜⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬛⬛⬛⬛🏽⬛⬛⬛⬛⬛⬛⬛🏽⬛⬛⬛⬛⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬛⬛⬛⬛🏽🏽🏽🏽🏽🏽🏽🏽🏽🏽🏽⬛⬛⬛⬛⬜⬜⬜⬜
⬜⬜⬜⬛⬛⬛🏽🏽🏽🏽🏽🏽⬛🏽⬛🏽🏽🏽🏽🏽🏽⬛⬛⬛⬜⬜⬜
⬜⬜⬛⬛⬛🟨🏽🏽🏽🏽🏽⬛⬛⬛⬛⬛🏽🏽🏽🏽🏽🟨⬛⬛⬛⬜⬜
⬜⬛⬛⬛🏽🟨🟨🟨⬛🏽🏽🏽🏽⬛🏽🏽🏽🏽⬛🟨🟨🟨🏽⬛⬛⬛⬜
⬛⬛⬛🏽🏽🏽🟨⬛⬛🏽🏽🏽🏽🏽🏽🏽🏽🏽⬛⬛🟨🏽🏽🏽⬛⬛⬛
⬛⬛⬛🏽🏽⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛🏽🏽⬛⬛⬛
⬛⬛⬛⬛⬛⬛⬛⬛⬛🟨🟨⬛🟨🟨🟨⬛🟨🟨⬛⬛⬛⬛⬛⬛⬛⬛⬛
⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛
⬛⬛⬛⬛⬛⬛⬛⬛⬛🏽🏽⬛⬛⬛⬛⬛🏽🏽⬛⬛⬛⬛⬛⬛⬛⬛⬛
⬜⬛⬛⬛⬛⬛⬛⬛🏽🏽🏽🏽⬛⬜⬛🏽🏽🏽🏽⬛⬛⬛⬛⬛⬛⬛⬜
⬜⬜⬛⬛⬛⬛⬜⬜⬛⬛⬛⬛⬛⬜⬛⬛⬛⬛⬛⬜⬜⬛⬛⬛⬛⬜⬜
⬜⬜⬜⬛⬛⬜⬜⬜⬛⬛⬛⬛⬜⬜⬜⬛⬛⬛⬛⬜⬜⬜⬛⬛⬜⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬜⬜⬜⬜⬜⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜"
ui_print ""
ui_print "█▓▒▒░░░🅵🅸🅽🅰🅻 🅵🅸🅶🅷🆃 🅰🅶🅰🅸🅽🆂🆃 🆂🅿🅸🅳🅴🆁🅼🅰🅽░░░▒▒▓█"
ui_print ""
ui_print "
⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬛⬛🟥🟥🟥🟥🟥⬛⬛⬜⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬛🟥🟥🟥🟥🟥🟥🟥🟥🟥⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬛🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥⬛⬜⬜⬜⬜⬜⬜
⬜⬜⬛🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥⬛⬜⬜⬜⬜⬜⬜
⬜⬛🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥⬛⬜⬜⬜⬜⬜
⬜⬛🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥⬛⬜⬜⬜⬜⬜
⬜⬛🟥🟥🟥🟥🟥🟥🟥🟥⬛⬛🟥🟥🟥⬛⬜⬜⬜⬜⬜
⬜⬛🟥🟥🟥🟥🟥🟥⬛⬛⬜⬛🟥🟥🟥⬛⬜⬜⬜⬜⬜
⬜⬛🟥🟥🟥🟥🟥⬛⬜⬜⬜⬛🟥🟥⬛⬜⬜⬜⬜⬜⬜
⬜⬜⬛🟥🟥🟥⬛⬜⬜⬜⬛🟥🟥🟥⬛⬜⬜⬜⬜⬜⬜
⬜⬜⬛🟥🟥⬛⬜⬜⬜⬛🟥🟥🟥🟥⬛⬜⬜⬜⬜⬜⬜
⬜⬜⬛🟥🟥🟥⬛⬛⬛🟥🟥🟥⬛⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬛🟥🟥🟥🟥🟥🟥🟥⬛🟥⬛⬜⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬛🟥🟥🟥🟥⬛⬛🟥🟥⬛⬛⬜⬜⬜⬜⬜⬜
⬜⬜⬜⬜⬜⬛⬛⬛⬛🟥⬛🟥🟥🟥🟥⬛⬛⬜⬜⬜⬜
⬜⬜⬜⬛⬛⬛🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥⬛⬜⬜⬜
⬜⬜⬛🟥⬛🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥⬛⬜⬜
⬜⬜⬛⬛🟥🟥🟥🟥🟥🟥🟥🟥🟥🟦🟥🟥🟥🟥⬛⬜⬜
⬜⬜⬛⬛⬛🟥⬛🟥⬛⬛🟥🟦🟦🟦🟦🟦🟥🟥🟥⬛⬜
⬜⬛🟥⬛🟥 ZNY.⬛🟥🟥🟥🟦🟦🟦🟦🟦🟦🟥🟥⬛⬜
⬜⬛🟥⬛⬛🟥⬛🟥⬛⬛🟦🟦🟦⬛⬛🟦🟦🟦🟥⬛⬜
⬜⬛🟥⬛🟥⬛⬛⬛🟥🟥🟦🟦⬛⬜⬜⬛🟦🟦🟦🟥⬛
⬜⬛🟥⬛🟥🟥⬛🟥🟥🟦🟦⬛⬜⬜⬜⬛🟦🟦🟦🟥⬛
⬜⬜⬛⬛🟥🟥🟥🟥🟦🟦🟦⬛⬜⬜⬜⬜⬛🟦🟦🟥⬛
⬜⬛🟥⬛🟥🟥🟥🟥🟥🟦🟦⬛⬜⬜⬜⬜⬛🟦🟦🟥⬛
⬜⬛🟥⬛⬛🟥🟥🟥🟥🟦🟦🟦⬛⬜⬜⬜⬛🟦🟦🟥⬛
⬛🟥🟥⬛🟦⬛🟥🟥🟦🟦🟦🟦⬛⬜⬜⬛🟥🟦🟥🟥⬛
⬛🟥⬛⬛🟦🟦⬛⬛🟦🟦🟦🟦🟦⬛⬛🟥🟥🟥🟥🟥⬛
⬛🟥⬛🟦🟦🟦🟦⬛🟦🟦🟦🟦🟦🟦⬛🟥⬛🟥🟥🟥⬛
⬛🟥⬛🟦🟦🟦🟦🟦⬛🟦🟦🟦🟦🟦⬛⬛⬛🟥🟥🟥⬛
⬜⬛⬛🟦🟦🟦🟦🟦⬛🟦🟦🟦🟦🟦⬛⬛🟥🟥⬛⬛⬜
⬜⬜⬛🟦🟦🟦🟦🟦⬛🟦🟦🟦🟦🟦🟦⬛⬛⬛⬜⬜⬜
⬜⬜⬜⬛🟦🟦🟦⬛⬜⬛🟦🟦🟦🟦🟦⬛⬜⬜⬜⬜⬜
⬜⬜⬛🟦🟦🟦🟦⬛⬜⬛🟦🟦🟦🟦⬛⬛⬜⬜⬜⬜⬜
⬜⬜⬛⬛⬛⬛⬛⬛⬜⬜⬛⬛⬛⬛🟥🟥⬛⬜⬜⬜⬜
⬜⬜⬛🟥🟥🟥🟥⬛⬜⬜⬛🟥🟥🟥🟥🟥⬛⬜⬜⬜⬜
⬜⬜⬛🟥🟥🟥🟥⬛⬜⬜⬜⬛🟥🟥🟥🟥⬛⬜⬜⬜⬜
⬜⬜⬛🟥🟥🟥🟥⬛⬜⬜⬜⬛🟥🟥🟥🟥⬛⬜⬜⬜⬜
⬜⬜⬛🟥🟥🟥🟥⬛⬜⬜⬜⬜⬛🟥🟥🟥🟥⬛⬜⬜⬜
⬜⬜⬛🟥🟥🟥🟥⬛⬜⬜⬜⬜⬛🟥🟥🟥🟥⬛⬜⬜⬜
⬜⬛🟥🟥🟥🟥🟥⬛⬜⬜⬜⬜⬛🟥🟥🟥🟥🟥⬛⬜⬜
⬛🟥🟥🟥🟥🟥⬛⬜⬜⬜⬜⬜⬜⬛🟥🟥🟥🟥⬛⬜⬜
⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜⬛🟥🟥🟥🟥⬛⬜⬜
⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬛⬜⬜"
ui_print ""
ui_print "

 ▄▄ ▀█▀ █ █ █▀▀   █▀█ █▀█ █  █  █ █▀▀ █▀█
      █  █▀█ ██▄   █▀▀ █▄█ ▀▄▀▄▀  ██▄ █▀▄"
sleep 1
ui_print ""
ui_print "█████████████████████████████████████████████████"
ui_print ""
sleep 1
ui_print "
═════════════════════════║
████████╗██╗░░██╗███████╗║
╚══██╔══╝██║░░██║██╔════╝║
░░░██║░░░███████║█████╗░░║
░░░██║░░░██╔══██║██╔══╝░░║
░░░██║░░░██║░░██║███████╗║
░░░╚═╝░░░╚═╝░░╚═╝╚══════╝║══════════════════════════║
░██████╗███████╗██████╗░██╗░░░██╗██╗░█████╗░███████╗║
██╔════╝██╔════╝██╔══██╗██║░░░██║██║██╔══██╗██╔════╝║
╚█████╗░█████╗░░██████╔╝╚██╗░██╔╝██║██║░░╚═╝█████╗░░║
░╚═══██╗██╔══╝░░██╔══██╗░╚████╔╝░██║██║░░██╗██╔══╝░░║
██████╔╝███████╗██║░░██║░░╚██╔╝░░██║╚█████╔╝███████╗║
╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚══════╝║
█▄─▄─▀█─▄▄─█─▄▄─█─▄▄▄▄█─▄─▄─█║══════════════════════║
██─▄─▀█─██─█─██─█▄▄▄▄─███─███║
▀▄▄▄▄▀▀▄▄▄▄▀▄▄▄▄▀▄▄▄▄▄▀▀▄▄▄▀▀║
═════════════════════════════║"
ui_print ""
ui_print "█████████████████████████████████████████████████"
sleep 1 
ui_print "█▓▒▒░░░WELCOME TO ZnySu Official░░░▒▒▓█"
sleep 1 
ui_print "█▓▒▒░░░THE SERVICE ZnySu Official░░░▒▒▓█"
sleep 1 
ui_print "█▓▒▒░░░Perfomance Universal Android░░░▒▒▓█"
sleep 1
ui_print "█████████████████████████████████████████████████"
ui_print "█▓▒▒░░░DEVICE $(getprop ro.product.brand)░░░▒▒▓█"
sleep 1
ui_print "█▓▒▒░░░MODEL $(getprop ro.product.model)░░░▒▒▓█"
sleep 1
ui_print "█▓▒▒░░░CPU $(getprop ro.hardware)░░░▒▒▓█"
sleep 1
ui_print "█▓▒▒░░░GPU $(getprop ro.hardware.egl)░░░▒▒▓█"
sleep 1
ui_print "█▓▒▒░░░SDK $(getprop ro.build.version.sdk)░░░▒▒▓█"
sleep 1
ui_print "█████████████████████████████████████████████████"
sleep 8
ui_print ""
ui_print "█▓▒▒░░░ Installing Module Please Wait ░░░▒▒▓█"

echo "█▓▒▒░░░ RESETPROP SUKSES FULL ░░░▒▒▓█"
    
    echo "█▓▒▒░░░ 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗘𝗗 𝗖𝗟𝗔𝗦𝗛 𝗢𝗙 𝗖𝗟𝗔𝗡 ░░░▒▒▓█"
coc() {
cmd game mode performance com.supercell.clashofclans
device_config put game_overlay com.supercell.clashofclans mode=2,fps=144
dumpsys deviceidle whitelist +com.supercell.clashofclans
appops set com.supercell.clashofclans RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f com.supercell.clashofclans
cmd package compile -m speed --secondary-dex -f com.supercell.clashofclans
cmd package compile -m speed --check-prof false -f com.supercell.clashofclans
cmd package compile -r first-boot -f com.supercell.clashofclans
}
coc > /dev/null 2>&1
echo "█▓▒▒░░░ SUKSES FULL ░░░▒▒▓█"

echo "█▓▒▒░░░ 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗘𝗗 𝗖𝗔𝗟𝗟 𝗢𝗙 𝗗𝗨𝗧𝗬 𝗠𝗢𝗕𝗜𝗟𝗘 ░░░▒▒▓█"
codm() {
cmd game mode performance com.garena.game.codm
device_config put game_overlay com.garena.game.codm mode=2,fps=144
dumpsys deviceidle whitelist +com.garena.game.codm
appops set com.garena.game.codm RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f com.garena.game.codm
cmd package compile -m speed --secondary-dex -f com.garena.game.codm
cmd package compile -m speed --check-prof false -f com.garena.game.codm
cmd package compile -r first-boot -f com.garena.game.codm
}
codm > /dev/null 2>&1
echo "█▓▒▒░░░ SUKSES FULL ░░░▒▒▓█"

echo "█▓▒▒░░░ 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗘𝗗 𝗙𝗜𝗥𝗘 𝗙𝗥𝗘𝗘 𝗠𝗔𝗫 ░░░▒▒▓█"
ffmax() {
cmd game mode performance com.dts.freefiremax
device_config put game_overlay com.dts.freefiremax mode=2,fps=144
dumpsys deviceidle whitelist +com.dts.freefiremax
appops set com.dts.freefiremax RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f com.dts.freefiremax
cmd package compile -m speed --secondary-dex -f com.dts.freefiremax
cmd package compile -m speed --check-prof false -f com.dts.freefiremax
cmd package compile -r first-boot -f com.dts.freefiremax
}
ffmax > /dev/null 2>&1
echo "█▓▒▒░░░ SUKSES FULL ░░░▒▒▓█"

echo "█▓▒▒░░░ 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗘𝗗 𝗙𝗜𝗥𝗘 𝗙𝗥𝗘𝗘 ░░░▒▒▓█"
ff() {
cmd game mode performance com.dts.freefireth
device_config put game_overlay com.dts.freefireth mode=2,fps=144
dumpsys deviceidle whitelist +com.dts.freefireth
appops set com.dts.freefireth RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f com.dts.freefireth
cmd package compile -m speed --secondary-dex -f com.dts.freefireth
cmd package compile -m speed --check-prof false -f com.dts.freefireth
cmd package compile -r first-boot -f com.dts.freefireth
}
ff > /dev/null 2>&1
echo "█▓▒▒░░░ SUKSES FULL ░░░▒▒▓█"

echo "█▓▒▒░░░ 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗘𝗗 𝗚𝗘𝗡𝗦𝗛𝗜𝗡 𝗜𝗠𝗣𝗔𝗖𝗧 ░░░▒▒▓█"
gens() {
cmd game mode performance com.miHoYo.GenshinImpact
device_config put game_overlay com.miHoYo.GenshinImpact mode=1,fps=144
dumpsys deviceidle whitelist +com.pubg.newstate
appops set com.miHoYo.GenshinImpact RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f com.miHoYo.GenshinImpact
cmd package compile -m speed --secondary-dex -f com.miHoYo.GenshinImpact
cmd package compile -m speed --check-prof false -f com.miHoYo.GenshinImpact
cmd package compile -r first-boot -f com.miHoYo.GenshinImpact
}
gens > /dev/null 2>&1
echo "█▓▒▒░░░ SUKSES FULL ░░░▒▒▓█"

echo "█▓▒▒░░░ 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗘𝗗 𝗛𝗢𝗡𝗢𝗥 𝗢𝗙 𝗞𝗜𝗡𝗚𝗦 ░░░▒▒▓█"
hok() {
cmd game mode performance com.levelinfinite.sgameGlobal.midaspay
device_config put game_overlay com.levelinfinite.sgameGlobal.midaspay mode=2,fps=144
dumpsys deviceidle whitelist +com.levelinfinite.sgameGlobal.midaspay
appops set com.levelinfinite.sgameGlobal.midaspay RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f com.levelinfinite.sgameGlobal.midaspay
cmd package compile -m speed --secondary-dex -f com.levelinfinite.sgameGlobal.midaspay
cmd package compile -m speed --check-prof false -f com.levelinfinite.sgameGlobal.midaspay
cmd package compile -r first-boot -f com.levelinfinite.sgameGlobal.midaspay
}
hok > /dev/null 2>&1
echo "█▓▒▒░░░ SUKSES FULL ░░░▒▒▓█"

echo "█▓▒▒░░░ 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗘𝗗 𝗛𝗢𝗡𝗢𝗥 𝗢𝗙 𝗞𝗜𝗡𝗚 𝗚𝗟𝗢𝗕𝗔𝗟 ░░░▒▒▓█"
hokg() {
cmd game mode performance com.levelinfinite.sgameGlobal
device_config put game_overlay com.levelinfinite.sgameGlobal mode=2,fps=144
dumpsys deviceidle whitelist +com.levelinfinite.sgameGlobal
appops set com.levelinfinite.sgameGlobal RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f com.levelinfinite.sgameGlobal
cmd package compile -m speed --secondary-dex -f com.levelinfinite.sgameGlobal
cmd package compile -m speed --check-prof false -f com.levelinfinite.sgameGlobal
cmd package compile -r first-boot -f com.levelinfinite.sgameGlobal
}
hokg > /dev/null 2>&1
echo "█▓▒▒░░░ SUKSES FULL ░░░▒▒▓█"

echo "█▓▒▒░░░ 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗘𝗗 𝗟𝗘𝗔𝗚𝗨𝗘 𝗢𝗙 𝗟𝗘𝗚𝗘𝗡𝗗𝗦 𝗪𝗜𝗟𝗗 𝗥𝗜𝗙𝗧 ░░░▒▒▓█"
lol() {
cmd game mode performance com.riotgames.league.wildrift
device_config put game_overlay com.riotgames.league.wildrift mode=2,fps=144
dumpsys deviceidle whitelist +com.riotgames.league.wildrift
appops set com.riotgames.league.wildrift RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f com.riotgames.league.wildrift
cmd package compile -m speed --secondary-dex -f com.riotgames.league.wildrift
cmd package compile -m speed --check-prof false -f com.riotgames.league.wildrift
cmd package compile -r first-boot -f com.riotgames.league.wildrift
}
lol > /dev/null 2>&1
echo "█▓▒▒░░░ SUKSES FULL ░░░▒▒▓█"

echo "█▓▒▒░░░ 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗘𝗗 𝗠𝗢𝗕𝗜𝗟𝗘 𝗟𝗘𝗚𝗘𝗡𝗗𝗦 𝗕𝗔𝗡𝗚 𝗕𝗔𝗡𝗚 ░░░▒▒▓█"
mlbb() {
cmd game mode performance com.mobile.legends
device_config put game_overlay com.mobile.legends mode=2,fps=144
dumpsys deviceidle whitelist +com.mobile.legends
appops set com.mobile.legends RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f com.mobile.legends
cmd package compile -m speed --secondary-dex -f com.mobile.legends
cmd package compile -m speed --check-prof false -f com.mobile.legends
cmd package compile -r first-boot -f com.mobile.legends
}
mlbb > /dev/null 2>&1
echo "█▓▒▒░░░ SUKSES FULL. ░░░▒▒▓█"

echo "█▓▒▒░░░ 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗘𝗗 𝗡𝗘𝗪 𝗦𝗧𝗔𝗧𝗘 𝗡𝗘𝗪 𝗘𝗥𝗔 𝗢𝗙 𝗕𝗥 ░░░▒▒▓█"
news() {
cmd game mode performance com.pubg.newstate
device_config put game_overlay com.pubg.newstate mode=2,fps=144
dumpsys deviceidle whitelist +com.pubg.newstate
appops set com.pubg.newstate RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f com.pubg.newstate
cmd package compile -m speed --secondary-dex -f com.pubg.newstate
cmd package compile -m speed --check-prof false -f com.pubg.newstate
cmd package compile -r first-boot -f com.pubg.newstate
}
news > /dev/null 2>&1
echo "█▓▒▒░░░ SUKSES FULL ░░░▒▒▓█"

echo "█▓▒▒░░░ 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗘𝗗 𝗣𝗨𝗕𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 ░░░▒▒▓█"
pubg() {
cmd game mode performance com.pubg.imobile
device_config put game_overlay com.pubg.imobile mode=2,fps=144
dumpsys deviceidle whitelist +com.pubg.imobile
appops set com.pubg.imobile RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f com.pubg.imobile
cmd package compile -m speed --secondary-dex -f com.pubg.imobile
cmd package compile -m speed --check-prof false -f com.pubg.imobile
cmd package compile -r first-boot -f com.pubg.imobile
}
pubg > /dev/null 2>&1
echo "█▓▒▒░░░ SUKSES FULL ░░░▒▒▓█"
sleep 10

# Patch the XML and place the modified one to the original directory
gms_doze_installer() {
ui_print "- Patching XML files"
GMS0="\"com.google.android.gms"\"
STR1="allow-in-power-save package=$GMS0"
STR2="allow-in-data-usage-save package=$GMS0"
NULL="/dev/null"
ui_print "- Finding system XML"
SYS_XML="$(
SXML="$(find /system_ext/* /system/* /product/* \
/vendor/* -type f -iname '*.xml' -print)"
for S in $SXML; do
  if grep -qE "$STR1|$STR2" $ROOT$S 2> $NULL; then
    echo "$S"
  fi
done
)"

PATCH_SX() {
for SX in $SYS_XML; do
  mkdir -p "$(dirname $MODPATH$SX)"
  cp -af $ROOT$SX $MODPATH$SX
  ui_print "  Patching: $SX"
  sed -i "/$STR1/d;/$STR2/d" $MODPATH/$SX
done

# Merge patched files under /system dir
for P in product vendor; do
  if [ -d $MODPATH/$P ]; then
    mkdir -p $MODPATH/system/$P
    mv -f $MODPATH/$P $MODPATH/system/
  fi
done
}

# Search and patch any conflicting modules (if present)
# Search conflicting XML files
MOD_XML="$(
MXML="$(find /data/adb/* -type f -iname "*.xml" -print)"
for M in $MXML; do
  if grep -qE "$STR1|$STR2" $M; then
    echo "$M"
  fi
done
)"

PATCH_MX() {
ui_print "- Finding conflicting XML"
for MX in $MOD_XML; do
  MOD="$(echo "$MX" | awk -F'/' '{print $5}')"
  ui_print "  $MOD: $MX"
  sed -i "/$STR1/d;/$STR2/d" $MX
done
}
}

# Install gms doze
gms_doze_installer

# Set permissions
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system/bin 0 0 0755 0755

# Clean up
find $MODPATH/* -maxdepth 0 \
              ! -name 'module.prop' \
              ! -name 'post-fs-data.sh' \
              ! -name 'service.sh' \
              ! -name 'LICENSE' \
              ! -name 'uninstall.sh' \
              ! -name 'system' \
              ! -name 'system.prop' \
                -exec rm -rf {} \;
                
                sleep 1 
am start -a android.intent.action.VIEW -d https://t.me/ZnySuDiscussiongroup/24243 >/dev/null 2>&1