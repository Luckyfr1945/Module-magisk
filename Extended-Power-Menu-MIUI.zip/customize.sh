##########################################################################################
#
# MMT Extended Config Script
#
##########################################################################################

# Set what you want to display when installing your module

ui_print " " 
ui_print "    Extended Power Menu MIUI    "
ui_print "   Modified By RaF   "
ui_print " "

##########################################################################################