MODDIR=${0%/*}
rm -rf $MODPATH/LICENSE
sleep 1

for i in $MODDIR/config/*; do
case $i in
*-ls|*-ls.sh);;
*) if [ -f "$i" -a -x "$i" ]; then $i & fi;;
esac
done
sleep 1