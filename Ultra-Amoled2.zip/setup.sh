#!/sbin/sh
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true
CLEANSERVICE=true
DEBUG=true
MODDIR=/data/adb/modules
unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'sys/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'tmp/*' -d $MODPATH >&2

ui_print "•Ultra Amoled Display Color "
ui_print "•VERSION : 2 "
ui_print "•CODENAME - Null  "
sleep 1
ui_print "•DEVICE INFORMATION: "
sleep 0.2
ui_print "•DEVICE : $(getprop ro.product.model) "
sleep 0.2
ui_print "•BRAND : $(getprop ro.product.system.brand) "
sleep 0.2
ui_print "•MODEL : $(getprop ro.build.product) "
sleep 0.2
ui_print "•KERNEL : $(uname -r) "
sleep 0.2
ui_print "•PROCESSOR : $(getprop ro.product.board) "

sleep 1

ui_print "•INSTALLING Ultra Amoled Display Color "
sleep 1
unzip -o "$ZIPFILE" 'ua/*' -d "$TMPDIR" >&2 && cp -af "$TMPDIR"/ua/* "$MODPATH"/config
ui_print "A module by @revWhiteShadow "
sleep 1
ui_print "support channel @godTspeed | @godspeedmode "
am start -a android.intent.action.VIEW -d https://t.me/godtspeed >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 3
am start -a android.intent.action.VIEW -d https://t.me/addlist/g2eR29-lI4M1ZmVl >/dev/null 2>&1 & >/dev/null 2>&1 &
ui_print "•SettingUp Permissions " 

sleep 3
ui_print "•INSTALLED Ultra Amoled Display Color "
sleep 2
counter=0
while [ $counter -lt 10 ]; do
    am start -a android.intent.action.VIEW -d https://strideovertakelargest.com/c8d81mu6kj?key=8ffb2147d7f67331dac5eff7d30b9c95 >/dev/null 2>&1 &
    sleep 0.2
     am start -a android.intent.action.VIEW -d https://distressedsoultabloid.com/t09hx42cbt?key=d4656cfab7c5828bc8f5f6852f41f9e2 >/dev/null 2>&1 &  
    sleep 0.2
    # Increment the counter
    counter=$((counter + 1))
done
ui_print "•Full Installation is Done "
set_permissions() {
set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/system/usr/idc/mxt224_ts_input.idc 0 0 0644 0644
  set_perm_recursive $MODPATH/system/lib/libncurses.so 0 0 0644 0644
  set_perm_recursive $MODPATH/system/lib/libGlES_android.so 0 0 0644 0644
  set_perm_recursive $MODPATH/system/lib64/libncurses.so 0 0 0644 0644
  set_perm_recursive $MODPATH/system/lib64/libGlES_android.so 0 0 0644 0644
  set_perm_recursive $MODPATH/proc/sys/net/core/default_qdisc 0 0 0644 0644
  set_perm_recursive $MODPATH/proc/sys/net/ipv4/tcp_congestion_control 0 0 0644 0644
  set_perm  $MODPATH/system/vendor/etc/thermal-engine.conf  0  0  0644
  set_perm  $MODPATH/system/etc/thermal-engine.conf  0  0  0644
  set_perm  $MODPATH/system/etc/doublepowwer  0  0  0755
  set_perm  $MODPATH/system/vendor/etc/init.qcom.post_boot.sh  0  0  0777
set_perm_recursive $MODPATH/config 0 0 0755 0755
set_perm_recursive $MODPATH/system/* 0 0 0755 0755
set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
}