#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# Universal HDR+ Display Booster by YayangProject

# Paksa HDR & Tone Mapping
setprop persist.sys.display.hdr_force true
setprop persist.sys.display.hdr_enhance 1
setprop persist.sys.display.tone_mapping true
setprop persist.sys.display.tone_map_strength 0.95
setprop persist.sys.display.color_boost 1

# Paksa SurfaceFlinger jalur HDR/Wide Color
setprop ro.surface_flinger.has_wide_color true
setprop ro.surface_flinger.has_HDR_display true
setprop ro.surface_flinger.use_color_management true
setprop ro.surface_flinger.set_color_matrix true
setprop ro.surface_flinger.wcg_composition_data_space 143261696

# Tambahan Rendering Optimization
setprop debug.hwui.renderer opengl
setprop debug.renderengine.backend skiagl
setprop debug.sf.enable_gl_backpressure 1
setprop debug.sf.disable_backpressure 0

# Tambahan keamanan display
setprop ro.surface_flinger.protected_contents true
setprop ro.display.color_depth 32
