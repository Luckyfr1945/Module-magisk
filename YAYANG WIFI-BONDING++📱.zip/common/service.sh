#!/system/bin/sh

# Log
log -p i -t YayangWiFi "Applying Mediatek WiFi Bonding & GCOR Tweaks"

# Boost GCOR dan sinyal WiFi
echo 1 > /proc/net/wireless/tx_power_override
echo 1 > /proc/net/wireless/gain_control
echo 1 > /proc/net/wireless/gcor_override

# Tambah kekuatan sinyal (pakai default gain maksimal jika bisa)
echo 29 > /proc/net/wireless/tx_gain
echo 29 > /proc/net/wireless/rx_gain

# Enable WiFi bonding (jika device support dual-band dual-concurrency)
setprop persist.vendor.wifi.dbdc_enable 1
setprop persist.vendor.wifi.enable_wifibonding 1
setprop persist.vendor.wifi.aggregation 1
setprop persist.vendor.wifi.mimo 1

# Nonaktifkan powersave
setprop persist.sys.wifi.powersave 0
setprop persist.vendor.wifi.powersave 0

# Tambahan: perkuat sinyal & bypass limit
if [ -e /proc/net/wireless/wifi_tx_power ]; then
  echo 20 > /proc/net/wireless/wifi_tx_power
fi

# Logging selesai
log -p i -t YayangWiFi "WiFi Tweaks Applied Successfully!"