game_performance () {
echo ""
echo ""
printf "\e[101m\e[1;77mNOTE!\e[0m\n"
echo ""
echo "ini menggabungkan kinerja mode permainan, konfigurasi game_overlay fps 120hz, pengoptimalan jit, dan menonaktifkan pengoptimalan baterai"
echo ""
echo "Anda hanya bisa memasukkan 1 paket saja, jika ingin paket yang lain masuk ke menu ini lagi"
echo ""
echo "E.g : com.dts.freefireth"
echo ""
echo -ne "${G}Enter Package Name:${F} "
read -s performa
echo "Prosesnya mungkin memakan waktu lama."
wew () {
cmd game mode performance $performa
device_config put game_overlay $performa mode=2,fps=120
dumpsys deviceidle whitelist +$performa
appops set $performa RUN_IN_BACKGROUND allow
cmd package compile -m everything-profile -f $performa
cmd package compile -m speed --secondary-dex -f $performa
cmd package compile -r first-boot -f $performa
cmd package compile -m speed --check-prof false -f $performa
}
wew > /dev/null 2>&1
echo "Done!"
}