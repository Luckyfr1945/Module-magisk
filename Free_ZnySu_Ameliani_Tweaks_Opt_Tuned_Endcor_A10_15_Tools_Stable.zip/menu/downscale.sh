downscale () {
echo ""
echo ""
animate_typing "Semakin besar angkanya, semakin tinggi resolusinya; semakin kecil angkanya, semakin rendah resolusinya." "41"
echo ""
animate_typing "rekomendasi 0.7 - 0.9" "42"
echo ""
echo ""
echo -ne "${G}Masukkan Faktor Downscale:${F} "
read -s scale_factor

current_resolution=$(wm size | awk '{print $3}')
IFS='x' read -r width height <<< "$current_resolution"
new_width=$(printf "%.0f" $(echo "$width * $scale_factor" | bc -l))
new_height=$(printf "%.0f" $(echo "$height * $scale_factor" | bc -l))
new_resolution="${new_width}x${new_height}"

echo ""
echo "${G}ini adalah pratinjau resolusi $new_resolution, akan disetel ulang setelah 5 detik, Ukuran kepadatan disetel ulang secara otomatis${F}"
sleep 1
wm density reset
wm size $new_resolution
sleep 5
wm size reset

echo ""
echo -ne "${G}apakah kamu yakin ingin mengubah resolusi ke $new_resolution? enter (y/n):${F} "
read -s choice
if [ "$choice" == "y" ]; then
  wm size $new_resolution
  #echo "$new_resolution"
  echo ""
  echo "Resolution changed from $current_resolution to $new_resolution"
  else
    echo ""
fi
}