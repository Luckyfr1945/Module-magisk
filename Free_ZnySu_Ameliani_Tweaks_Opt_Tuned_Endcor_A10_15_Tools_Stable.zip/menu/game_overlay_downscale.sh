game_overlay_downscale () {
echo ""
echo ""
printf "\e[101m\e[1;77mNOTE!\e[0m\n"
echo ""
echo "Anda hanya bisa memasukkan 1 paket saja, jika ingin paket yang lain masuk ke menu ini lagi"
echo ""
echo ""
echo -ne "${G}Enter Package Name:${F} "
read -s ofpsg
echo -ne "${G}Berapa banyak Downscale yang Anda inginkan? rekomendasi 1.0 to 0.5 :${F} "
read -s ofpsga
device_config put game_overlay $ofpsg mode=2,downscaleFactor=$ofpsga:mode=3,downscaleFactor=$ofpsga > /dev/null 2>&1
sleep 1
echo "Done! more information check ${G}https://t.me/ZnySuDiscussiongroup${F}"
}