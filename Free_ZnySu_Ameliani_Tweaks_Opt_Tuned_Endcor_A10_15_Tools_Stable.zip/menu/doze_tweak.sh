doze_tweak () {
echo ""
echo "" 
echo "\033[0;90m[ - ] Untuk mengabaikan Deep Doze dan membuang gerakan apa pun dengan meningkatkan batas waktu inactive_to dan motion_inactive_to ke angka yang sangat besar (e.g. 30 days) sehingga Deep Doze tidak pernah masuk ke status IDLE dan hanya Light Doze yang dapat mengelola status IDLE-nya. [ 1 ]"
echo ""
echo "[ - ] Untuk mengabaikan Light Doze karena alasan apa pun dengan melakukan pengaturan serupa dengan light_after_inactive_to sehingga Light Doze mungkin tidak pernah memasuki status IDLE. [ 2 ]"
echo ""
echo "[ - ] Untuk mengabaikan Deep Doze dan menggunakan Light Doze, tiru pengaturan waktu Deep Doze. [ 3 ]"
echo ""
echo "[ - ] Untuk diam secara tidak sengaja di awal dan terus diam semampunya tanpa memperhitungkan gerakan dengan mengabaikan Deep Doze yang sebenarnya dan menyetel Light Doze sehingga akan mulai diam lebih sedikit 30 menit ke 24 jam dengan peningkatan faktor 1,5; Tugas pemeliharaan akan dilakukan selama maksimal 30 detik dan alarm apa pun yang dibiarkan membangunkan Doze dari keadaan diam akan memiliki efek yang lebih kecil. [ 4 ]"
echo ""
echo "[ - ] Untuk diam sebisa mungkin tanpa memperhitungkan gerakan dengan mengabaikan Deep Doze yang sebenarnya dan menyetel Light Doze sehingga akan terperangkap dalam keadaan IDLE selama mungkin. Tugas pemeliharaan akan dilakukan sekitar dua kali sehari selama maksimal 30 detik dan alarm apa pun yang diizinkan untuk membangunkan Doze dari keadaan diam akan berdampak lebih kecil. [ 5 ]"
echo ""
echo "[ - ] Reset [ 6 ]${F}"
echo ""
echo -ne "${G}Select: ${F}"
read -s selc
while true; do
case $selc in
        1)
            echo ""
            settings put global device_idle_constants inactive_to=2592000000,motion_inactive_to=2592000000
            echo "Done!"
            ;;
        2)
            echo ""
            settings put global device_idle_constants light_after_inactive_to=2592000000
            echo "Done!"
            ;;
        3)
            echo ""
            settings put global device_idle_constants inactive_to=2592000000,motion_inactive_to=2592000000,light_after_inactive_to=3000000,light_max_idle_to=21600000,light_idle_to=3600000,light_idle_maintenance_max_budget=600000,min_light_maintenance_time=30000
            echo "Done!"
            ;;
        4)
            echo ""
            settings put global device_idle_constants inactive_to=2592000000,motion_inactive_to=2592000000,light_after_inactive_to=20000,light_pre_idle_to=30000,light_max_idle_to=86400000,light_idle_to=1800000,light_idle_factor=1.5,light_idle_maintenance_max_budget=30000,light_idle_maintenance_min_budget=10000,min_time_to_alarm=60000
            echo "Done!"
            ;;
        5)
            echo ""
            settings put global device_idle_constants inactive_to=2592000000,motion_inactive_to=2592000000,light_after_inactive_to=15000,light_pre_idle_to=30000,light_max_idle_to=86400000,light_idle_to=43200000,light_idle_maintenance_max_budget=30000,light_idle_maintenance_min_budget=10000,min_time_to_alarm=60000
            echo "Done!"
            ;;
        6)
           settings delete global device_idle_constants
            echo ""
            echo "Done!"
            ;;
          *)
            echo "Invalid option."
            ;;
        esac 
        break
      done
}