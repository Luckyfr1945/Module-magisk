game_overlay_fps () {
echo ""
echo ""
printf "\e[101m\e[1;77mNOTE!\e[0m\n"
echo ""
echo "Anda hanya bisa memasukkan 1 paket saja, jika ingin paket yang lain masuk ke menu ini lagi"
echo ""
echo ""
echo -ne "${G}Enter Package Name:${F} "
read -s fpspgc
echo -ne "${G}Kamu mau angka FPS berapa?:${F} "
read -s fpsgd
device_config put game_overlay $fpspgc mode=2,fps=$fpsgd:mode=3,fps=$fpsgd > /dev/null 2>&1
sleep 1
echo "Done! more information check ${G}https://t.me/ZnySuDiscussiongroup${F}"
}