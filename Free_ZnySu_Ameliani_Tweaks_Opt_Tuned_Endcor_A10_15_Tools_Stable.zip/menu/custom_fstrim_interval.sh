custom_fstrim_interval () {
echo ""
echo ""
animate_typing "[ - ] Setiap Reboot [ 1 ]" "90"
animate_typing "[ - ] Setiap hari [ 2 ]" "90"
animate_typing "[ - ] Setiap Hari Lainnya [ 3 ]" "90"
animate_typing "[ - ] Setiap Tiga Hari [ 4 ]" "90"
animate_typing "[ - ] Setiap Minggu [ 5 ]" "90"
animate_typing "[ - ] Setiap Setiap Bulan [ 6 ]" "90"
animate_typing "[ - ] Tidak diatur [ 7 ]" "90"
animate_typing "[ - ] Jangan pernah memaksa pemangkasan [ 8 ]" "90"
animate_typing "[ - ] Pangkas Cache Sekarang [ 9 ]" "90"
echo ""
echo -ne "${G}Select: ${F}"
read -s trimx
while true; do
case $trimx in
        1)
            settings put global fstrim_mandatory_interval 1
            echo ""
            echo "Done!"
            ;;
        2)
            settings put global fstrim_mandatory_interval 86400000
            echo ""
            echo "Done!"
            ;;
        3)
            settings put global fstrim_mandatory_interval 172800000
            echo ""
            echo "Done!"
            ;;
        4)
            settings put global fstrim_mandatory_interval 259200000
            echo ""
            echo "Done!"
            ;;
        5)
            settings put global fstrim_mandatory_interval 604800000
            echo ""
            echo "Done!"
            ;;
        6)
            settings put global fstrim_mandatory_interval 2592000000
            echo ""
            echo "Done!"
            ;;
        7)
            settings put global fstrim_mandatory_interval null
            echo ""
            echo "Done!"
            ;;
        8)
            settings put global fstrim_mandatory_interval 0
            echo ""
            echo "Done!"
            ;;
        9)
            pm trim-caches 99999G
            echo ""
            echo "Done!"
            ;;
          *)
            echo "Invalid option."
            ;;
        esac 
        break
      done
}