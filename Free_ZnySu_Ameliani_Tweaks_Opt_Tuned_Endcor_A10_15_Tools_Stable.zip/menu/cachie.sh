cachie () {
echo ""
echo ""
echo "${G}[ - ] Ambang pelaporan minimum penyimpanan rendah [ 1 ]${F}"
echo "${N}Persentase penyimpanan minimum yang tersedia untuk mempertimbangkan perangkat yang kehabisan penyimpanan${F}"
echo ""
echo "${G}[ - ] Ambang batas byte maksimum penyimpanan rendah [ 2 ]${F}"
echo "${N}Jumlah maksimum byte yang membatasi persentase di atas${F}"
echo ""
echo "${G}[ - ] Byte minimum penyimpanan maksimum [ 3 ]${F}"
echo "${N}Jumlah penyimpanan maksimum yang tersedia untuk mempertimbangkan perangkat agar terisi penuh; jumlah ini dicadangkan untuk sistem guna menghindari crash di seluruh sistem${G}"
echo ""
echo "${G}[ - ] Ambang batas minimum cache [ 4 ]${F}"
echo "${N}Persentase penyimpanan minimum yang dialokasikan untuk data cache${F}"
echo ""
echo "${G}[ - ] Ambang batas byte maksimum cache [ 5 ]${F}"
echo "${N}Jumlah maksimum byte yang membatasi persentase di atas${F}"
echo ""
echo "${G}[ - ] Diatur ke default [ 6 ]${F}"
echo ""
echo -ne "${G}Select: ${F}"
read -s cachiee
while true; do
case $cachiee in
        1)
            echo -ne "${G}Enter value:${F} "
            read -s sys_storage_threshold_percentage
            settings put global sys_storage_threshold_percentage $sys_storage_threshold_percentage
            echo ""
            echo "Done!"
            ;;
        2)
            echo -ne "${G}Enter Value:${F} "
            read -s sys_storage_threshold_max_bytes
            settings put global sys_storage_threshold_max_bytes $sys_storage_threshold_max_bytes
            echo ""
            echo "Done!"
            ;;
        3)
            echo -ne "${G}Enter Value:${F} "
            read -s sys_storage_full_threshold_bytes
            settings put global sys_storage_full_threshold_bytes $sys_storage_full_threshold_bytes
            echo ""
            echo "Done!"
            ;;
        4)
            echo -ne "${G}Enter value:${F} "
            read -s sys_storage_cache_percentage
            settings put global sys_storage_cache_percentage $sys_storage_cache_percentage
            echo ""
            echo "Done!"
            ;;
        5)
            echo -ne "${G}Enter value:${F} "
            read -s sys_storage_cache_max_bytes
            settings put global sys_storage_cache_max_bytes $sys_storage_cache_max_bytes
            echo ""
            echo "Done!"
            ;;
        6)
            cachl () {
            settings delete global sys_storage_threshold_percentage
            settings delete global sys_storage_threshold_max_bytes
            settings delete global sys_storage_full_threshold_bytes
            settings delete global sys_storage_cache_percentage
            settings delete global sys_storage_cache_max_bytes
            }
            cachl > /dev/null 2>&1
            echo ""
            echo "Done!"
            ;;
          *)
            echo "Invalid option."
            ;;
        esac 
        break
      done
}
