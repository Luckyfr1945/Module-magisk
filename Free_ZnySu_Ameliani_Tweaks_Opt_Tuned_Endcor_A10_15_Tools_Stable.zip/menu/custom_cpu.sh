custom_cpu(){

# Write Using Hand By ZnySu Official

# Check if the device supports changing CPU frequency
if [ -e /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_frequencies ]; then
    SUPPORTS_FREQ_CHANGE=true
else
    SUPPORTS_FREQ_CHANGE=false
fi

# Function to set CPU frequency for all CPUs
set_cpu_frequency() {
    if $SUPPORTS_FREQ_CHANGE; then
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_setspeed; do
            echo $1 > $cpu
        done
    else
        echo "Device does not support changing CPU frequency. Using alternative method to lock CPU speed."
        # Implement alternative method here to lock CPU speed
    fi
}

# Function to set CPU governor for all CPUs
set_cpu_governor() {
    available_governors=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors)
    governors_array=($available_governors)
    
    echo "Available CPU Governors:"
    for i in "${!governors_array[@]}"; do
        echo "$i. ${governors_array[$i]}"
    done
    echo -ne  "Enter the number of the CPU Governor you want to set: "
    read -s governor_number
    selected_governor=${governors_array[$governor_number]}
    
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        echo $selected_governor > $cpu
    done
    
    echo "CPU Governor set to $selected_governor for all CPUs"
}

# Function to get the maximum available speed for each CPU
get_max_speed() {
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_available_frequencies; do
        max_speed=$(cat $cpu | tr ' ' '\n' | sort -n | tail -1)
        echo "Max Speed for $(basename $(dirname $cpu)): $max_speed kHz"
    done
}

# Function to save battery by turning off 2 little CPUs and 2 big CPUs and normalizing all CPU speeds
save_battery() {
    # Turn off 2 little CPUs
    echo 0 > /sys/devices/system/cpu/cpu0/online
    echo 0 > /sys/devices/system/cpu/cpu2/online
    # Turn off 2 big CPUs
    echo 0 > /sys/devices/system/cpu/cpu4/online
    echo 0 > /sys/devices/system/cpu/cpu6/online
    # Normalize all CPU speeds
    set_cpu_frequency "1000000"  # Set speed to 1 GHz for all CPUs
}

while true
do
    clear
    echo "${G}Menu Custom CPU Speed${F}"
    echo "${N}1. Atur CPU Governor untuk semua CPU"
    echo "${N}2. Paksa Kecepatan Maksimum / Hemat Baterai"
    echo "${N}3. Tampilkan Kecepatan CPU Saat Ini untuk semua CPU"
    echo "${N}4. Exit"
    echo -ne "${G}Masukkan pilihan Anda: ${F}"
    read -s choice

    case $choice in
        1)
            set_cpu_governor
            sleep 2
            ;;
        2)
            echo -ne  "Enter sub-choice (1 for Force Max Speed, 2 for Force Save Battery, 3 Back): "
            read -s sub_choice
            case $sub_choice in
                1)
                    get_max_speed
                    sleep 5
                    ;;
                2)
                    save_battery
                    echo "Battery saving mode activated."
                    sleep 2
                    ;;
                3)
                    custom_cpu
                    sleep 2
                    ;;
                *)
                    echo "Invalid sub-choice. Please enter a valid option."
                    sleep 2
                    ;;
            esac
            ;;
        3)
            for cpu in /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_cur_freq; do
                echo "Current CPU Speed for $(basename $(dirname $cpu)): $(cat $cpu) kHz"
            done
            sleep 5
            ;;
        4)
            echo "Exiting..."
            break
            ;;
        *)
            echo "Invalid choice. Please enter a valid option."
            sleep 2
            ;;
    esac
done
}