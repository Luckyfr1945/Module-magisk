#!/system/bin/sh
wait_until_login() {
    # In case of /data encryption is disabled
    while [[ "$(getprop sys.boot_completed)" != "1" ]]; do
        sleep 3
    done
    # We don't have the permission to rw "/storage/emulated/0" before the user unlocks the screen
    test_file="/storage/emulated/0/Android/.PERMISSION_TEST"
    true >"$test_file"
    while [[ ! -f "$test_file" ]]; do
        true >"$test_file"
        sleep 1
    done
    rm -f "$test_file"
}

su -lp 2000 -c "cmd notification post -S bigtext -t 'YAYANG PROJECT ROGV2' tag 'ROGV2 ACTIVATED'"
####################################
# System Tweaks (from Melody Script)
####################################
cmd settings put global activity_starts_logging_enabled 0
cmd settings put global ble_scan_always_enabled 0
cmd settings put global hotword_detection_enabled 0
cmd settings put global mobile_data_always_on 0
cmd settings put global network_recommendations_enabled 0
cmd settings put global wifi_scan_always_enabled 0
cmd settings put secure adaptive_sleep 0
cmd settings put secure screensaver_activate_on_dock 0
cmd settings put secure screensaver_activate_on_sleep 0
cmd settings put secure screensaver_enabled 0
cmd settings put secure send_action_app_error 0
cmd settings put system air_motion_engine 0
cmd settings put system air_motion_wake_up 0
cmd settings put system intelligent_sleep_mode 0
cmd settings put system master_motion 0
cmd settings put system motion_engine 0
cmd settings put system nearby_scanning_enabled 0
cmd settings put system nearby_scanning_permission_allowed 0
cmd settings put system rakuten_denwa 0
cmd settings put system send_security_reports 0

####################################
# CPU Governor Enhancements
####################################
# Tuning CPU governors for little cores (cpu0-3)
for cpu in /sys/devices/system/cpu/cpu[0-3]; do
    min_freq=$(cat $cpu/cpufreq/cpuinfo_min_freq)
    max_freq=$(cat $cpu/cpufreq/cpuinfo_max_freq)
    mid_freq=$(( ($min_freq + $max_freq) / 2 ))

    echo "Setting governor for LITTLE cores"
    echo "schedutil" > "$cpu/cpufreq/scaling_governor"
    echo $mid_freq > "$cpu/cpufreq/scaling_min_freq"
    echo $max_freq > "$cpu/cpufreq/scaling_max_freq"
    echo 75 > "$cpu/cpufreq/schedutil/hispeed_load"
    echo 20000 > "$cpu/cpufreq/schedutil/io_wait_boost_enable"
done

# Tuning CPU governors for big cores (cpu4-7)
for cpu in /sys/devices/system/cpu/cpu[4-7]; do
    min_freq=$(cat $cpu/cpufreq/cpuinfo_min_freq)
    max_freq=$(cat $cpu/cpufreq/cpuinfo_max_freq)
    mid_freq=$(( ($min_freq + $max_freq) / 2 ))

    echo "Setting governor for BIG cores"
    echo "schedutil" > "$cpu/cpufreq/scaling_governor"
    echo $mid_freq > "$cpu/cpufreq/scaling_min_freq"
    echo $max_freq > "$cpu/cpufreq/scaling_max_freq"
done

# Setting performance mode globally
for cpu in /sys/devices/system/cpu/cpu[0-7]; do
    echo performance > "$cpu/cpufreq/scaling_governor"
done


####################################
# I/O Scheduler and Performance
####################################
# Set default I/O scheduler to deadline
echo "deadline" > /sys/block/mmcblk0/queue/scheduler
echo "deadline" > /sys/block/sda/queue/scheduler

# Optimize read/write requests
echo 128 > /sys/block/mmcblk0/queue/nr_requests

# Optimize disk I/O for performance
fstrim -v /cache
fstrim -v /system
fstrim -v /vendor
fstrim -v /data
fstrim -v /preload
fstrim -v /product
fstrim -v /metadata
fstrim -v /odm

####################################
# Kernel Debugging and Logging
####################################
# Disable unnecessary kernel logging
for i in "debug_mask" "log_level*" "debug_level*" "*debug_mode" "enable_ramdumps" "edac_mc_log*" "enable_event_log" "*log_level*" "*log_ue*" "*log_ce*" "log_ecn_error" "snapshot_crashdumper" "seclog*" "compat-log" "*log_enabled" "tracing_on" "mballoc_debug"; do
    for o in $(find /sys/ -type f -name "$i"); do
        echo "0" > "$o"
    done
done

# Disable kernel panic and error logs
echo 0 > /proc/sys/kernel/panic
echo 0 > /proc/sys/kernel/panic_on_oops
echo 0 > /proc/sys/kernel/panic_on_warn
echo 0 > /proc/sys/kernel/panic_on_rcu_stall
echo 0 > /sys/module/kernel/parameters/panic
echo 0 > /sys/module/kernel/parameters/panic_on_warn
echo 0 > /sys/module/kernel/parameters/pause_on_oops
echo 0 > /sys/module/kernel/panic_on_rcu_stall

# Disable kernel dump on crash
echo 0 > /sys/module/spurious/parameters/noirqdebug
echo 0 > /sys/kernel/debug/sde_rotator0/evtlog/enable
echo 0 > /sys/kernel/debug/dri/0/debug/enable

####################################
# Battery and Power Optimization
####################################
# Increase max charging current for better battery life
ext 5000000 /sys/class/power_supply/usb/current_max
ext 5100000 /sys/class/power_supply/usb/hw_current_max
ext 5100000 /sys/class/power_supply/usb/pd_current_max
ext 5100000 /sys/class/power_supply/usb/ctm_current_max
ext 5000000 /sys/class/power_supply/main/current_max
ext 5100000 /sys/class/power_supply/main/constant_charge_current_max
ext 5000000 /sys/class/power_supply/battery/current_max
ext 5100000 /sys/class/power_supply/battery/constant_charge_current_max
ext 5500000 /sys/class/qcom-battery/restricted_current

####################################
# Disable Logs and Clean Cache
####################################
# Clean up system logs
rm -rf /data/log/*
rm -rf /data/system/dropbox/*
rm -rf /data/system/usagestats/*
rm -rf /data/anr/*
rm -rf /dev/log/*
rm -rf /data/tombstones/*
rm -rf /data/media/0/MIUI/Gallery
rm -rf /data/media/0/MIUI/.debug_log
rm -rf /data/media/0/MIUI/BugReportCache
rm -rf /data/media/0/mtklog
rm -rf /data/system/cache/*
rm -rf /sys/kernel/debug/*

# Clear Wi-Fi logs
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs

# Release cache on boot
echo "3" > /proc/sys/vm/drop_caches
echo "1" > /proc/sys/vm/compact_memory

####################################
# Final Notification
####################################
su -lp 2000 -c "cmd notification post -S bigtext -t 'YAYANG PROJECT ROGV2' tag 'ROGV2 ACTIVATED'"