#!/system/bin/sh
# Service Script for Magisk Module

MODDIR=${0%/*}
SCRIPT_DIR="$MODDIR/script"
MAIN_SCRIPT="$SCRIPT_DIR/yayangproject.sh"

# Tunggu sampai boot selesai
while [[ "$(getprop sys.boot_completed)" != "1" ]]; do
    sleep 3
done

# Tunggu tambahan untuk pastikan system benar-benar ready
sleep 10

# Jalankan script utama jika ada
if [ -f "$MAIN_SCRIPT" ]; then
    sh "$MAIN_SCRIPT"
fi

exit 0