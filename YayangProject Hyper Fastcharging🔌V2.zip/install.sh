##########################################################################################
#
# Magisk Module Installer Script
#
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false

##########################################################################################
# Replace list
##########################################################################################

REPLACE="
"

##########################################################################################
# Function Callbacks
##########################################################################################

print_modname() {
  ui_print " "
  ui_print "╔═══════════════════════════════════════════════╗"
  ui_print "║    🅈 🅐 🅨 🅐 🅝 🅖   🅟 🅡 🅞 🅙 🅔 🅒 🅣        ║"
  ui_print "║        🄷 🅈 🄿 🄴 🅁   🄵 🄰 🅂 🅃 🄲 🄷 🄰 🅁 🄶 🄸 🄽 🄶   🅅 2.𝟎        ║"
  ui_print "║     𝕌 ℕ 𝕀 𝕍 𝔼 ℝ 𝕊 𝔸 𝕃   𝔸 𝕃 𝕃   𝔻 𝔼 𝕍 𝕀 ℂ 𝔼 𝕊     ║"
  ui_print "╚═══════════════════════════════════════════════╝"
  ui_print " "
  sleep 1

  ui_print "⚡ [ HYPER FASTCHARGING CORE ]"
  ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  ui_print " 🔋 Maximum Charging Current & Voltage Boost"
  ui_print " ⚡ Intelligent Charging Speed Optimization"
  ui_print " 🔥 Advanced Thermal Control During Charging"
  ui_print " 💨 USB/Type-C PD Fast Charging Enhancement"
  ui_print " 🔋 Wireless Charging Speed Boost"
  ui_print " 📊 Real-time Charging Statistics & Monitoring"
  ui_print " "

  sleep 1
  ui_print "🛡️ [ BATTERY PROTECTION SYSTEM ]"
  ui_print " ───────────────────────────────"
  ui_print " 🔋 Smart Battery Health Preservation"
  ui_print " 🌡️ Dynamic Thermal Management"
  ui_print " ⚡ Overcharge & Overvoltage Protection"
  ui_print " 🔄 Optimal Charging Cycle Management"
  ui_print " 💯 Battery Longevity Optimization"
  ui_print " "

  sleep 1
  ui_print "🔌 [ CHARGING HARDWARE OPTIMIZATION ]"
  ui_print " ──────────────────────────────────"
  ui_print " 📱 Universal Fast Charging Support"
  ui_print " 🔷 Qualcomm Quick Charge Enhancement"
  ui_print " ⚡ USB Power Delivery Max Tuning"
  ui_print " 🔶 MediaTek Pump Express Optimization"
  ui_print " 🔥 VOOC/Dash/Warp Charging Compatibility"
  ui_print " 🔋 Wireless Charging Coil Efficiency"
  ui_print " "

  sleep 1
  ui_print "📊 [ CHARGING INTELLIGENCE ]"
  ui_print " ──────────────────────────"
  ui_print " 🧠 AI-Powered Charging Algorithm"
  ui_print " ⏰ Smart Charging Schedule Optimization"
  ui_print " 🌙 Night Charging Pattern Enhancement"
  ui_print " 🎯 Gaming While Charging Performance"
  ui_print " 🔄 Adaptive Charging Speed Control"
  ui_print " "

  sleep 1
  ui_print "🔧 [ SYSTEM INTEGRATION ]"
  ui_print " ───────────────────────"
  ui_print " ⚡ Kernel Charging Driver Optimization"
  ui_print " 🔋 Power Supply Subsystem Enhancement"
  ui_print " 📱 Charging LED & Notification Control"
  ui_print " 🔄 Battery Stats Calibration"
  ui_print " 🛡️ Safety Certification & Compliance"
  ui_print " "

  sleep 1
  ui_print "🚀 [ PERFORMANCE BOOST ]"
  ui_print " ──────────────────────"
  ui_print " ⚡ Charging While Using Device Optimization"
  ui_print " 🎮 Gaming Performance During Charging"
  ui_print " 📱 Multitasking Power Management"
  ui_print " 🔥 Heat Dissipation & Performance Balance"
  ui_print " "

  ui_print "╔═══════════════════════════════════════════════╗"
  ui_print "║           🄸 🄽 🅂 🅃 🄰 🄻 🄻 🄰 🅃 🄸 🄾 🄽           ║"
  ui_print "╚═══════════════════════════════════════════════╝"
  sleep 2
}

on_install() {
  ui_print " "
  ui_print "📦 EXTRACTING HYPER FASTCHARGING FILES..."
  ui_print "▸ Charging Optimization Files..."
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  
  ui_print "▸ Fast Charging Scripts..."
  unzip -o "$ZIPFILE" 'script/*' -d $MODPATH >&2 2>/dev/null || true
  
  ui_print "▸ Battery Management Binaries..."
  unzip -o "$ZIPFILE" 'bin/*' -d $MODPATH >&2 2>/dev/null || true
  
  ui_print "✅ HYPER FASTCHARGING SYSTEM INSTALLED"
  ui_print " "
}

set_permissions() {
  ui_print "🔐 CONFIGURING PERMISSIONS..."
  
  ui_print "▸ Module Directory Permissions..."
  set_perm_recursive $MODPATH 0 0 0755 0644
  
  ui_print "▸ Script Execution Permissions..."
  [ -d "$MODPATH/script" ] && set_perm_recursive $MODPATH/script 0 0 0755 0755
  [ -f "$MODPATH/script/yayangproject.sh" ] && set_perm $MODPATH/script/yayangproject.sh 0 0 0755
  
  ui_print "▸ Binary File Permissions..."
  [ -d "$MODPATH/bin" ] && set_perm_recursive $MODPATH/bin 0 0 0755 0755
  [ -d "$MODPATH/system/bin" ] && set_perm_recursive $MODPATH/system/bin 0 2000 0755 0755
  
  ui_print "▸ Vendor Configuration Permissions..."
  [ -d "$MODPATH/system/vendor" ] && set_perm_recursive $MODPATH/system/vendor 0 0 0755 0644
  [ -d "$MODPATH/system/vendor/etc" ] && set_perm_recursive $MODPATH/system/vendor/etc 0 0 0755 0644
  
    ui_print "✅ PERMISSIONS CONFIGURED"
  ui_print " "
  
  ui_print "╔═══════════════════════════════════════════════╗"
  ui_print "║         🄸 🄽 🅂 🅃 🄰 🄻 🄻 🄰 🅃 🄸 🄾 🄽   🄲 🄾 🄼 🄿 🄻 🄴 🅃 🄴        ║"
  ui_print "╚═══════════════════════════════════════════════╝"
  ui_print " "
  ui_print "🎉 YAYANG PROJECT HYPER FASTCHARGING V2.0 INSTALLED!"
  ui_print " "
  ui_print "⚡ Features Activated:"
  ui_print "▸ Hyper Fast Charging Technology"
  ui_print "▸ Advanced Battery Protection"
  ui_print "▸ Multi-Platform Fast Charge Support"
  ui_print "▸ AI-Powered Charging Algorithm"
  ui_print " "
  ui_print "📱 Recommended: Reboot device to activate charging tweaks"
  ui_print "⏰ First charge cycle may take longer for calibration"
  ui_print "🔋 Use original charger for best results"
  ui_print " "
  ui_print "🌐 Channel: t.me/yayangshibainuproject"
  ui_print "💬 Discussion: t.me/+0IFlcbM8t3k1MTVl"
  ui_print " "
  ui_print "⭐ Thank you for choosing Yayang Project Hyper Fastcharging!"
  ui_print " "
  sleep 1
  /system/bin/am start -a android.intent.action.VIEW -d "https://t.me/yayangshibainuproject"
  busybox sleep 1
}