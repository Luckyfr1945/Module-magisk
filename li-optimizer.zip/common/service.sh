#!/system/bin/sh
MODDIR=${0%/*}

sleep 60

if [[ ! $(cmd -l | grep app_hibernation) ]]; then
echo "Not Supported"
exit
fi

for app in $(cmd package list packages | cut -f 2 -d ":"); do
if [[ ! "$app" == "com.termux" ]] && [[ ! "$app" == "eu.sisik.hackendebug" ]]; then
echo "$app has been hibernated"
cmd app_hibernation set-state --user 0 --global "$app" true
echo ""
fi

device_config put app_hibernation app_hibernation_enabled true
device_config put permissions \
  auto_revoke_unused_threshold_millis2 99
done

exit 0