SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

ui_print "**************************************************"
ui_print "* SUPER HIBERNATOR  "
ui_print "* Tg @zenin_911                 "
ui_print "**************************************************"
ui_print " improve your performance, battery life, heating"
ui_print "**************************************************"
ui_print ""
sleep 4
am start -a android.intent.action.VIEW -d https://t.me/makistuffs
sleep 7
unzip -o "$ZIPFILE" system/* -d $MODPATH >&2
sleep 2
set_perm_recursive $MODPATH 0 0 0755 0644